const jwt = require("jsonwebtoken");

const JWT_SECRET = process.env.JWT_SECRET || "ssl-monitor-secret-key-change-in-prod";

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: "Invalid or expired token" });
  }
}

function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
}

// Blocks readonly users from any write operation
function notReadonly(req, res, next) {
  if (req.user?.role === "readonly") {
    return res.status(403).json({ error: "Read-only access — not permitted" });
  }
  next();
}

module.exports = { authMiddleware, adminOnly, notReadonly, JWT_SECRET };
