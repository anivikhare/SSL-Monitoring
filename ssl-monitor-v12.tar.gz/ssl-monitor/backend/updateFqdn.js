const { nowIST } = require("./timeHelper");

// Build the full UPDATE query + params for a check result.
// If prevRow is provided and the cert's expiry or issuer changed (and we have a valid new cert),
// records prev_* values and cert_changed_at.
function buildFqdnUpdate(result, id, prevRow = null) {
  let prevExpiry = prevRow ? prevRow.prev_expiry_date : null;
  let prevIssuer = prevRow ? prevRow.prev_issuer : null;
  let certChangedAt = prevRow ? prevRow.cert_changed_at : null;

  // Only detect change when the new check yielded a valid cert (has expiry, no hard error)
  const newHasCert = result.expiryDate && !result.error;
  if (prevRow && newHasCert && prevRow.expiry_date) {
    const expiryChanged = prevRow.expiry_date !== result.expiryDate;
    const issuerChanged = (prevRow.issuer || "") !== (result.issuer || "");
    if (expiryChanged || issuerChanged) {
      prevExpiry = prevRow.expiry_date;
      prevIssuer = prevRow.issuer || null;
      certChangedAt = nowIST();
    }
  }

  const sql = `UPDATE fqdns SET
    status=?, expiry_date=?, days_left=?, last_error=?, last_checked=?,
    response_time_ms=?, issuer=?, issuer_cn=?, subject_cn=?, san=?,
    valid_from=?, chain_valid=?, chain_error=?, protocol=?, cipher=?,
    prev_expiry_date=?, prev_issuer=?, cert_changed_at=?
    WHERE id=?`;
  const params = [
    result.status,
    result.expiryDate,
    result.daysLeft,
    result.error || null,
    nowIST(),
    result.response_time_ms ?? null,
    result.issuer ?? null,
    result.issuer_cn ?? null,
    result.subject_cn ?? null,
    result.san ?? null,
    result.valid_from ?? null,
    result.chain_valid ?? null,
    result.chain_error ?? null,
    result.protocol ?? null,
    result.cipher ?? null,
    prevExpiry,
    prevIssuer,
    certChangedAt,
    id,
  ];
  return { sql, params };
}

module.exports = { buildFqdnUpdate };
