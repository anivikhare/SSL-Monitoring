// Store as UTC — frontend displays in IST
function nowIST() {
  return new Date().toISOString().replace("T", " ").split(".")[0];
}
module.exports = { nowIST };
