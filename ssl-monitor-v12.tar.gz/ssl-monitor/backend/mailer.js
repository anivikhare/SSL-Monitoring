const nodemailer = require("nodemailer");
const { getDb } = require("./db");

function getSettings() {
  return new Promise((resolve, reject) => {
    const db = getDb();
    db.all("SELECT key, value FROM settings", (err, rows) => {
      if (err) return reject(err);
      const s = {};
      rows.forEach((r) => (s[r.key] = r.value));
      resolve(s);
    });
  });
}

async function getTransporter() {
  const s = await getSettings();
  if (!s.smtp_host) throw new Error("SMTP host not configured");
  const auth = s.smtp_user && s.smtp_pass
    ? { user: s.smtp_user, pass: s.smtp_pass }
    : undefined;
  return nodemailer.createTransport({
    host: s.smtp_host,
    port: parseInt(s.smtp_port) || 25,
    secure: s.smtp_secure === "true",
    auth,
    tls: { rejectUnauthorized: false },
  });
}

async function sendTestEmail(to) {
  const s = await getSettings();
  if (!to) throw new Error("No recipient provided");
  const transporter = await getTransporter();
  await transporter.sendMail({
    from: s.smtp_from,
    to,
    subject: "SSL Monitor — Test Email",
    html: `
      <h2 style="color:#2563eb">SSL Monitor</h2>
      <p>This is a test email from your SSL Monitor instance.</p>
      <p>If you received this, SMTP is configured correctly.</p>
      <hr/><small>Sent at ${new Date().toISOString()}</small>
    `,
  });
}

// Severity helpers
function getSeverity(daysLeft) {
  if (daysLeft <= 0)  return { label: "EXPIRED",  color: "#dc2626", bg: "#fef2f2", border: "#fca5a5" };
  if (daysLeft <= 7)  return { label: "CRITICAL",  color: "#dc2626", bg: "#fef2f2", border: "#fca5a5" };
  if (daysLeft <= 14) return { label: "WARNING",   color: "#d97706", bg: "#fffbeb", border: "#fcd34d" };
  return               { label: "EXPIRING SOON", color: "#2563eb", bg: "#eff6ff", border: "#93c5fd" };
}

function buildAlertHtml(certs, scopeName) {
  const now = new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
  const total = certs.length;
  const critical = certs.filter(c => c.days_left <= 7).length;
  const warning  = certs.filter(c => c.days_left > 7 && c.days_left <= 14).length;
  const expiring = certs.filter(c => c.days_left > 14).length;

  // Summary cards
  const summaryCards = [
    { label: "Total Certs",    value: total,    color: "#2563eb", bg: "#eff6ff" },
    { label: "Critical (≤7d)", value: critical, color: "#dc2626", bg: "#fef2f2" },
    { label: "Warning (≤14d)", value: warning,  color: "#d97706", bg: "#fffbeb" },
    { label: "Expiring Soon",  value: expiring, color: "#059669", bg: "#f0fdf4" },
  ].map(s => `
    <td style="width:25%;padding:0 6px">
      <div style="background:${s.bg};border-radius:8px;padding:14px 12px;text-align:center">
        <div style="font-size:28px;font-weight:800;color:${s.color};line-height:1">${s.value}</div>
        <div style="font-size:11px;color:#64748b;margin-top:4px;text-transform:uppercase;letter-spacing:0.5px">${s.label}</div>
      </div>
    </td>`).join("");

  // Cert rows
  const rows = certs.map((c, i) => {
    const sev = getSeverity(c.days_left);
    const bg = i % 2 === 0 ? "#ffffff" : "#f8fafc";
    return `
      <tr style="background:${bg}">
        <td style="padding:10px 14px;border-bottom:1px solid #e2e8f0">
          <div style="font-family:monospace;font-size:13px;font-weight:600;color:#1e293b">${c.fqdn}</div>
          <div style="font-size:11px;color:#94a3b8;margin-top:2px">Port ${c.port} &bull; ${c.group_name || "—"}</div>
        </td>
        <td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;text-align:center;font-size:13px;color:#475569">
          ${c.expiry_date || "—"}
        </td>
        <td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;text-align:center">
          <span style="display:inline-block;background:${sev.bg};color:${sev.color};border:1px solid ${sev.border};
            padding:3px 10px;border-radius:100px;font-size:11px;font-weight:700;letter-spacing:0.5px">
            ${sev.label}
          </span>
        </td>
        <td style="padding:10px 14px;border-bottom:1px solid #e2e8f0;text-align:center;
          font-size:22px;font-weight:800;color:${sev.color}">
          ${c.days_left <= 0 ? "0" : c.days_left}
          <div style="font-size:10px;font-weight:400;color:#94a3b8">days left</div>
        </td>
      </tr>`;
  }).join("");

  return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:32px 16px">
<tr><td>
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:680px;margin:0 auto">

  <!-- Header -->
  <tr>
    <td style="background:#1e3a5f;
      border-radius:12px 12px 0 0;padding:28px 32px">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td>
            <div style="display:inline-block;background:rgba(255,255,255,0.15);
              border-radius:8px;padding:8px 12px;margin-bottom:12px">
              <span style="font-size:20px">🔒</span>
              <span style="color:white;font-size:13px;font-weight:700;
                letter-spacing:1px;vertical-align:middle;margin-left:6px">SSL MONITOR</span>
            </div>
            <h1 style="color:white;margin:0 0 6px;font-size:22px;font-weight:800">
              SSL Certificate Expiry Alert
            </h1>
            <p style="color:rgba(255,255,255,0.75);margin:0;font-size:13px">
              Project / Group: <strong style="color:white">${scopeName}</strong>
            </p>
          </td>
          <td style="text-align:right;vertical-align:top">
            <div style="background:rgba(255,255,255,0.1);border-radius:8px;
              padding:10px 16px;text-align:center">
              <div style="color:rgba(255,255,255,0.7);font-size:10px;
                text-transform:uppercase;letter-spacing:1px">Alert Time</div>
              <div style="color:white;font-size:12px;font-weight:600;margin-top:2px">${now} IST</div>
            </div>
          </td>
        </tr>
      </table>
    </td>
  </tr>

  <!-- Summary Cards -->
  <tr>
    <td style="background:white;padding:20px 32px;border-left:1px solid #e2e8f0;
      border-right:1px solid #e2e8f0">
      <div style="font-size:11px;font-weight:700;color:#94a3b8;
        text-transform:uppercase;letter-spacing:1px;margin-bottom:12px">Summary</div>
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr style="margin:0 -6px">${summaryCards}</tr>
      </table>
    </td>
  </tr>

  <!-- Table Header -->
  <tr>
    <td style="background:#f8fafc;padding:10px 32px;
      border:1px solid #e2e8f0;border-top:none;border-bottom:none">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <th style="text-align:left;font-size:11px;color:#64748b;
            text-transform:uppercase;letter-spacing:0.8px;font-weight:700;
            padding:6px 0;width:50%">Domain</th>
          <th style="text-align:center;font-size:11px;color:#64748b;
            text-transform:uppercase;letter-spacing:0.8px;font-weight:700;
            padding:6px 0;width:20%">Expiry Date</th>
          <th style="text-align:center;font-size:11px;color:#64748b;
            text-transform:uppercase;letter-spacing:0.8px;font-weight:700;
            padding:6px 0;width:15%">Status</th>
          <th style="text-align:center;font-size:11px;color:#64748b;
            text-transform:uppercase;letter-spacing:0.8px;font-weight:700;
            padding:6px 0;width:15%">Days Left</th>
        </tr>
      </table>
    </td>
  </tr>

  <!-- Cert Rows -->
  <tr>
    <td style="border:1px solid #e2e8f0;border-top:none;border-bottom:none">
      <table width="100%" cellpadding="0" cellspacing="0">${rows}</table>
    </td>
  </tr>

  <!-- Footer -->
  <tr>
    <td style="background:#0f172a;border-radius:0 0 12px 12px;padding:20px 32px">
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td>
            <p style="color:rgba(255,255,255,0.6);font-size:12px;margin:0">
              This is an automated alert from <strong style="color:white">SSL Monitor</strong>
              &bull; Reliance Industries Limited
            </p>
            <p style="color:rgba(255,255,255,0.4);font-size:11px;margin:6px 0 0">
              Please do not reply to this email. To manage alert settings, contact your administrator.
            </p>
          </td>
          <td style="text-align:right;vertical-align:middle">
            <div style="background:rgba(255,255,255,0.08);border-radius:6px;
              padding:6px 12px;display:inline-block">
              <span style="color:rgba(255,255,255,0.5);font-size:10px">Powered by</span>
              <span style="color:white;font-size:12px;font-weight:700;margin-left:4px">🔒 SSL Monitor</span>
            </div>
          </td>
        </tr>
      </table>
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>`;
}

// Core alert function — sends separate emails per project/group
async function sendExpiryAlerts(force = false) {
  const s = await getSettings();
  if (s.alerts_enabled !== "true") return { skipped: "alerts disabled" };
  if (!s.smtp_host) return { skipped: "smtp not configured" };

  const thresholds = (s.alert_thresholds || "30,14,7")
    .split(",").map(Number).sort((a, b) => b - a);

  const db = getDb();

  return new Promise((resolve) => {
    // Fetch all fqdns with project + group info including alert_emails
    db.all(
      `SELECT f.*,
        p.id AS project_id, p.name AS project_name, p.alert_emails AS project_emails, p.cc_emails AS project_cc,
        g.name AS group_name, g.alert_emails AS group_emails, g.cc_emails AS group_cc
       FROM fqdns f
       JOIN groups g ON g.id = f.group_id
       JOIN projects p ON p.id = g.project_id
       WHERE f.days_left IS NOT NULL`,
      async (err, fqdns) => {
        if (err || !fqdns || !fqdns.length) return resolve({ checked: 0 });

        // Determine which fqdns need alerts
        const DAILY_THRESHOLD = parseInt(s.daily_alert_days || "7"); // configurable from UI
        const today = new Date().toISOString().split("T")[0]; // YYYY-MM-DD

        const toAlert = [];
        for (const f of fqdns) {
          // ── Expired certs → always alert daily ──────────────────────────
          if (f.status === "Expired" || f.days_left <= 0) {
            // alert_sent stores last alerted date for expired e.g. "expired:2026-06-29"
            const lastExpiredDate = (f.alert_sent || "").match(/expired:(\d{4}-\d{2}-\d{2})/)?.[1];
            if (force || lastExpiredDate !== today) {
              toAlert.push({ ...f, threshold: 0 });
              const base = (f.alert_sent || "").replace(/expired:\d{4}-\d{2}-\d{2}/, "").replace(/^,|,$|,,/g, "");
              db.run("UPDATE fqdns SET alert_sent=? WHERE id=?",
                [(base ? base + "," : "") + "expired:" + today, f.id]);
            }
            continue;
          }

          // ── Certs within DAILY_THRESHOLD → alert every day ───────────────
          if (f.days_left <= DAILY_THRESHOLD) {
            // alert_sent stores last daily alert date e.g. "daily:2026-06-29"
            const lastDailyDate = (f.alert_sent || "").match(/daily:(\d{4}-\d{2}-\d{2})/)?.[1];
            if (force || lastDailyDate !== today) {
              toAlert.push({ ...f, threshold: DAILY_THRESHOLD });
              const base = (f.alert_sent || "").replace(/daily:\d{4}-\d{2}-\d{2}/, "").replace(/^,|,$|,,/g, "");
              db.run("UPDATE fqdns SET alert_sent=? WHERE id=?",
                [(base ? base + "," : "") + "daily:" + today, f.id]);
            }
            continue;
          }

          // ── Certs above DAILY_THRESHOLD → alert once per threshold ───────
          if (force) {
            const applicableThreshold = thresholds.find(t => f.days_left <= t);
            if (applicableThreshold !== undefined) {
              toAlert.push({ ...f, threshold: applicableThreshold });
            }
          } else {
            const alreadySent = (f.alert_sent || "").split(",").map(s => parseInt(s)).filter(n => !isNaN(n));
            for (const threshold of thresholds) {
              if (threshold <= DAILY_THRESHOLD) continue; // handled above
              if (f.days_left <= threshold && !alreadySent.includes(threshold)) {
                toAlert.push({ ...f, threshold });
                const newSent = [...alreadySent, threshold].join(",");
                db.run("UPDATE fqdns SET alert_sent=? WHERE id=?", [newSent, f.id]);
                break;
              }
            }
          }
        }

        if (!toAlert.length) return resolve({ checked: fqdns.length, alerted: 0 });

        try {
          const transporter = await getTransporter();
          let totalSent = 0;

          // ── Group-level alerts (group has its own emails) ─────────────────
          // Group fqdns by group_id where group has alert_emails set
          const byGroup = {};
          for (const f of toAlert) {
            if (f.group_emails && f.group_emails.trim()) {
              if (!byGroup[f.group_id]) byGroup[f.group_id] = { certs: [], emails: f.group_emails, name: `${f.project_name} › ${f.group_name}` };
              byGroup[f.group_id].certs.push(f);
            }
          }

          for (const groupId of Object.keys(byGroup)) {
            const { certs, emails, name } = byGroup[groupId];
            const minDays = Math.min(...certs.map((c) => c.days_left || 0));
            const subject = minDays <= 0
              ? `🚨 SSL Alert [${name}] — ${certs.length} cert(s) EXPIRED`
              : `⚠️ SSL Alert [${name}] — ${certs.length} cert(s) expiring soon`;
            const groupCc = [
              ...(s.global_cc ? s.global_cc.split(",").map(e => e.trim()).filter(Boolean) : []),
              ...(certs[0]?.group_cc ? certs[0].group_cc.split(",").map(e => e.trim()).filter(Boolean) : []),
            ].join(",");
            await transporter.sendMail({ from: s.smtp_from, to: emails, cc: groupCc || undefined, subject, html: buildAlertHtml(certs, name) });
            totalSent++;
            console.log(`[ALERT] Group email sent → ${name} → TO:${emails} CC:${groupCc || "none"}`);
          }

          // ── Project-level alerts (project has emails, for fqdns not covered by group emails) ──
          const byProject = {};
          for (const f of toAlert) {
            // Skip if already handled by group-level
            if (f.group_emails && f.group_emails.trim()) continue;
            if (f.project_emails && f.project_emails.trim()) {
              if (!byProject[f.project_id]) byProject[f.project_id] = { certs: [], emails: f.project_emails, name: f.project_name };
              byProject[f.project_id].certs.push(f);
            }
          }

          for (const projectId of Object.keys(byProject)) {
            const { certs, emails, name } = byProject[projectId];
            const minDays = Math.min(...certs.map((c) => c.days_left || 0));
            const subject = minDays <= 0
              ? `🚨 SSL Alert [${name}] — ${certs.length} cert(s) EXPIRED`
              : `⚠️ SSL Alert [${name}] — ${certs.length} cert(s) expiring soon`;
            const projectCc = [
              ...(s.global_cc ? s.global_cc.split(",").map(e => e.trim()).filter(Boolean) : []),
              ...(certs[0]?.project_cc ? certs[0].project_cc.split(",").map(e => e.trim()).filter(Boolean) : []),
            ].join(",");
            await transporter.sendMail({ from: s.smtp_from, to: emails, cc: projectCc || undefined, subject, html: buildAlertHtml(certs, name) });
            totalSent++;
            console.log(`[ALERT] Project email sent → ${name} → TO:${emails} CC:${projectCc || "none"}`);
          }

          resolve({ checked: fqdns.length, alerted: toAlert.length, emails_sent: totalSent });
        } catch (mailErr) {
          console.error("[ALERT] Failed:", mailErr.message);
          resolve({ error: mailErr.message });
        }
      }
    );
  });
}

function resetAlertsIfRenewed(fqdnId, newDaysLeft) {
  const db = getDb();
  db.get("SELECT alert_sent FROM fqdns WHERE id=?", [fqdnId], (err, row) => {
    if (err || !row || !row.alert_sent) return;
    const sent = row.alert_sent.split(",").map(Number).filter(Boolean);
    const stillValid = sent.filter((t) => newDaysLeft <= t);
    db.run("UPDATE fqdns SET alert_sent=? WHERE id=?", [stillValid.join(","), fqdnId]);
  });
}

module.exports = { getSettings, sendTestEmail, sendExpiryAlerts, resetAlertsIfRenewed, sendReminderEmails };

// Send reminder emails using SSL-alert-style thresholds + daily repeat
async function sendReminderEmails() {
  const { getDb } = require("./db");
  const db = getDb();
  const s = await getSettings().catch(() => ({}));
  if (!s.smtp_host) { console.log("[REMINDER] SMTP not configured, skipping"); return { sent: 0 }; }

  // Same thresholds as SSL alerts
  const thresholds = (s.alert_thresholds || "30,14,7")
    .split(",").map(t => parseInt(t.trim())).filter(Boolean).sort((a, b) => b - a);
  const dailyBelow = parseInt(s.daily_alert_days || "7");
  const todayStr = new Date().toLocaleString("sv-SE", { timeZone: "Asia/Kolkata" }).split(" ")[0];

  return new Promise((resolve) => {
    db.all(
      `SELECT r.*, f.fqdn AS fqdn_name, p.name AS project_name
       FROM reminders r
       LEFT JOIN fqdns f ON f.id = r.fqdn_id
       LEFT JOIN projects p ON p.id = r.project_id
       WHERE r.done = 0`,
      async (err, rows) => {
        if (err || !rows || !rows.length) return resolve({ sent: 0 });
        let sent = 0;
        let transporter;
        try { transporter = await getTransporter(); } catch (e) { return resolve({ sent: 0 }); }

        const globalCc = s.global_cc || "";

        for (const r of rows) {
          // Days until the reminder date
          const remindDate = new Date(r.remind_date + "T00:00:00+05:30");
          const now = new Date(todayStr + "T00:00:00+05:30");
          const daysLeft = Math.round((remindDate - now) / (1000 * 60 * 60 * 24));

          const to = r.email_to || globalCc;
          if (!to) continue;
          // Combine reminder CC + global CC
          const ccList = [r.email_cc, globalCc].filter(c => c && c !== to).join(",");

          // Determine if we should send today
          let shouldSend = false;
          let reason = "";
          const firedThresholds = (r.notified_thresholds || "").split(",").filter(Boolean);

          if (daysLeft < 0) {
            // Overdue — send daily
            shouldSend = true; reason = `overdue by ${Math.abs(daysLeft)} day(s)`;
          } else if (daysLeft <= dailyBelow) {
            // Within daily-repeat window — send once per day
            const dailyKey = `daily:${todayStr}`;
            if (!firedThresholds.includes(dailyKey)) {
              shouldSend = true; reason = `${daysLeft} day(s) left`;
              firedThresholds.push(dailyKey);
            }
          } else {
            // Check threshold crossings (one-time each)
            for (const t of thresholds) {
              if (daysLeft <= t && !firedThresholds.includes(`t:${t}`)) {
                shouldSend = true; reason = `${daysLeft} day(s) left (${t}-day threshold)`;
                firedThresholds.push(`t:${t}`);
                break;
              }
            }
          }

          if (!shouldSend) continue;

          // Urgency color based on days left
          let urgencyColor = "#0f766e", urgencyBg = "#d1fae5", urgencyLabel = reason;
          if (daysLeft < 0) { urgencyColor = "#b91c1c"; urgencyBg = "#fee2e2"; }
          else if (daysLeft === 0) { urgencyColor = "#c2410c"; urgencyBg = "#ffedd5"; }
          else if (daysLeft <= 7) { urgencyColor = "#b45309"; urgencyBg = "#fef3c7"; }
          else { urgencyColor = "#1d4ed8"; urgencyBg = "#dbeafe"; }

          const detailRow = (label, value) => value ? `
            <tr>
              <td style="padding:8px 0;border-bottom:1px solid #eef2f6;color:#64748b;font-size:13px;width:120px;vertical-align:top">${label}</td>
              <td style="padding:8px 0;border-bottom:1px solid #eef2f6;color:#1e293b;font-size:14px;font-weight:600">${value}</td>
            </tr>` : "";

          const html = `
          <div style="background:#f1f5f9;padding:24px 0;font-family:-apple-system,Segoe UI,Arial,sans-serif">
            <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;margin:0 auto">
              <tr><td>
                <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,0.1)">
                  <!-- Header -->
                  <tr>
                    <td style="background:#1e3a5f;padding:20px 28px">
                      <table role="presentation" cellpadding="0" cellspacing="0" width="100%">
                        <tr>
                          <td style="color:#ffffff;font-size:19px;font-weight:700">🔔 SSL Monitor Reminder</td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Urgency banner -->
                  <tr>
                    <td style="padding:16px 28px 0">
                      <table role="presentation" cellpadding="0" cellspacing="0">
                        <tr>
                          <td style="background:${urgencyBg};color:${urgencyColor};font-size:12px;font-weight:700;padding:6px 14px;border-radius:100px;text-transform:uppercase;letter-spacing:0.5px">
                            ${urgencyLabel}
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                  <!-- Title -->
                  <tr>
                    <td style="padding:14px 28px 4px">
                      <div style="font-size:22px;font-weight:700;color:#0f172a">${r.title}</div>
                    </td>
                  </tr>
                  <!-- Details table -->
                  <tr>
                    <td style="padding:12px 28px 8px">
                      <table role="presentation" cellpadding="0" cellspacing="0" width="100%">
                        ${detailRow("Due Date", r.remind_date)}
                        ${detailRow("Project", r.project_name)}
                        ${detailRow("Domain", r.fqdn_name ? `<span style="font-family:monospace">${r.fqdn_name}</span>` : "")}
                      </table>
                    </td>
                  </tr>
                  ${r.notes ? `
                  <!-- Notes -->
                  <tr>
                    <td style="padding:8px 28px 20px">
                      <div style="color:#64748b;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Notes</div>
                      <div style="background:#f8fafc;border:1px solid #eef2f6;padding:14px 16px;border-radius:8px;color:#334155;font-size:14px;line-height:1.6">${r.notes}</div>
                    </td>
                  </tr>` : `<tr><td style="padding-bottom:12px"></td></tr>`}
                  <!-- Footer -->
                  <tr>
                    <td style="background:#f8fafc;padding:14px 28px;border-top:1px solid #eef2f6">
                      <div style="color:#94a3b8;font-size:12px">Sent by SSL Monitor · JioGames Infrastructure</div>
                    </td>
                  </tr>
                </table>
              </td></tr>
            </table>
          </div>`;
          try {
            await transporter.sendMail({
              from: s.smtp_from,
              to,
              cc: ccList || undefined,
              subject: `🔔 Reminder: ${r.title} (${reason})`,
              html,
            });
            db.run("UPDATE reminders SET notified=1, notified_thresholds=? WHERE id=?",
              [firedThresholds.join(","), r.id]);
            sent++;
            console.log(`[REMINDER] Sent "${r.title}" to ${to} — ${reason}`);
          } catch (e) {
            console.log(`[REMINDER] Failed for "${r.title}": ${e.message}`);
          }
        }
        resolve({ sent });
      }
    );
  });
}
