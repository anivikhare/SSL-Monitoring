const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
const { getDb } = require("./db");
const { checkSSLBatch, checkSSL } = require("./sslChecker");
const { nowIST } = require("./timeHelper");
const { buildFqdnUpdate } = require("./updateFqdn");
const { sendExpiryAlerts, resetAlertsIfRenewed, getSettings, sendReminderEmails } = require("./mailer");

const authRoutes     = require("./routes/auth");
const projectRoutes  = require("./routes/projects");
const groupRoutes    = require("./routes/groups");
const fqdnRoutes     = require("./routes/fqdns");
const settingsRoutes = require("./routes/settings");
const trashRoutes      = require("./routes/trash");
const activityRoutes   = require("./routes/activity");
const reminderRoutes   = require("./routes/reminders");

const app  = express();
const PORT = process.env.PORT || 8000;

app.use(cors({ origin: "*" }));
app.use(express.json());

getDb();

app.use("/api/auth",     authRoutes);
app.use("/api/projects", projectRoutes);
app.use("/api/groups",   groupRoutes);
app.use("/api/fqdns",    fqdnRoutes);
app.use("/api/settings", settingsRoutes);
app.use("/api/trash",    trashRoutes);
app.use("/api/activity", activityRoutes);
app.use("/api/reminders", reminderRoutes);
app.get("/api/health",   (req, res) => res.json({ status: "ok" }));

// ─── Dynamic Cron Manager ────────────────────────────────────────────────────
let sslCheckJob  = null;
let alertJob     = null;

async function runSSLCheck() {
  console.log(`[CRON] SSL check started at ${new Date().toISOString()}`);
  const db = getDb();
  const s = await getSettings().catch(() => ({}));
  const proxyHost = s.proxy_host || "";
  const proxyPort = s.proxy_port || "8080";
  db.all("SELECT * FROM fqdns", async (err, rows) => {
    if (err || !rows || !rows.length) return;
    const results = await checkSSLBatch(rows, 10, proxyHost, proxyPort);
    rows.forEach((row, i) => {
      const r = results[i];
      const u = buildFqdnUpdate(r, row.id, row);
      db.run(u.sql, u.params);
      if (r.daysLeft && r.daysLeft > 30) resetAlertsIfRenewed(row.id, r.daysLeft);
    });
    console.log(`[CRON] Checked ${rows.length} FQDNs — alerts will fire at scheduled alert time only`);
  });
}

async function runAlertOnly() {
  console.log(`[CRON] Alert check started at ${new Date().toISOString()}`);
  const result = await sendExpiryAlerts();
  console.log("[CRON] Alert result:", JSON.stringify(result));
  // Reminders use the same schedule + thresholds as SSL alerts
  try {
    const rem = await sendReminderEmails();
    console.log("[CRON] Reminder result:", JSON.stringify(rem));
  } catch (e) {
    console.log("[CRON] Reminder error:", e.message);
  }
}

function isValidCron(expr) {
  return cron.validate(expr);
}

async function scheduleCronJobs() {
  let s;
  try { s = await getSettings(); } catch (e) {
    s = { cron_ssl_check: "0 */6 * * *", cron_alert: "30 2 * * *" };
  }

  const sslExpr   = s.cron_ssl_check || "0 */6 * * *";
  const alertExpr = s.cron_alert     || "30 2 * * *";

  // Stop existing jobs
  if (sslCheckJob)  { sslCheckJob.stop();  sslCheckJob  = null; }
  if (alertJob)     { alertJob.stop();     alertJob     = null; }

  // Schedule SSL check job
  if (isValidCron(sslExpr)) {
    sslCheckJob = cron.schedule(sslExpr, runSSLCheck);
    console.log(`[CRON] SSL check scheduled: ${sslExpr}`);
  } else {
    console.error(`[CRON] Invalid SSL check cron: ${sslExpr} — using default`);
    sslCheckJob = cron.schedule("0 */6 * * *", runSSLCheck);
  }

  // Schedule alert job
  if (isValidCron(alertExpr)) {
    alertJob = cron.schedule(alertExpr, runAlertOnly);
    console.log(`[CRON] Alert scheduled: ${alertExpr}`);
  } else {
    console.error(`[CRON] Invalid alert cron: ${alertExpr} — using default`);
    alertJob = cron.schedule("30 2 * * *", runAlertOnly);
  }
}

// Expose reschedule function — called when settings are saved
app.reschedule = scheduleCronJobs;

// ─── Reschedule endpoint — called from settings route after save ──────────────
app.post("/api/internal/reschedule", (req, res) => {
  scheduleCronJobs().then(() => res.json({ message: "Cron jobs rescheduled" }));
});

// ─── Startup: check PENDING FQDNs ────────────────────────────────────────────
setTimeout(() => {
  const db = getDb();
  db.all("SELECT * FROM fqdns WHERE status='PENDING' OR status IS NULL", async (err, rows) => {
    if (err || !rows || !rows.length) return;
    console.log(`[STARTUP] Checking ${rows.length} PENDING FQDNs...`);
    const results = await checkSSLBatch(rows, 10);
    rows.forEach((row, i) => {
      const r = results[i];
      const u = buildFqdnUpdate(r, row.id, row);
      db.run(u.sql, u.params);
    });
    console.log(`[STARTUP] Done checking PENDING FQDNs`);
  });
}, 3000);

// Auto-heal — retry ERROR FQDNs every hour until they succeed
cron.schedule("0 * * * *", async () => {
  const db = getDb();
  const s = await getSettings().catch(() => ({}));
  const proxyHost = s.proxy_host || "";
  const proxyPort = s.proxy_port || "8080";

  db.all(
    `SELECT * FROM fqdns WHERE (status = 'Error' OR status = '403 Proxy Blocked') AND deleted_at IS NULL`,
    async (err, rows) => {
      if (err || !rows || !rows.length) return;
      console.log(`[AUTO-HEAL] Retrying ${rows.length} failed FQDN(s)...`);

      for (const row of rows) {
        try {
          const result = await checkSSL(row.fqdn, row.port, !!row.use_proxy, proxyHost, proxyPort);
          const u = buildFqdnUpdate(result, row.id, row);
          db.run(u.sql, u.params);
          if (result.status !== 'Error' && result.status !== '403 Proxy Blocked') {
            console.log(`[AUTO-HEAL] ✓ ${row.fqdn} recovered — status: ${result.status}`);
          } else {
            console.log(`[AUTO-HEAL] ✗ ${row.fqdn} still failing — ${result.error}`);
          }
        } catch (e) {
          console.log(`[AUTO-HEAL] ✗ ${row.fqdn} exception — ${e.message}`);
        }
      }
    }
  );
});

// Auto-purge trash older than 30 days — runs daily at 2 AM UTC
cron.schedule("0 2 * * *", () => {
  const db = getDb();
  const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  db.run("DELETE FROM fqdns WHERE deleted_at IS NOT NULL AND deleted_at < ?", [cutoff]);
  db.run("DELETE FROM groups WHERE deleted_at IS NOT NULL AND deleted_at < ?", [cutoff]);
  db.run("DELETE FROM projects WHERE deleted_at IS NOT NULL AND deleted_at < ?", [cutoff], function() {
    if (this.changes > 0) console.log(`[TRASH] Auto-purged items older than 30 days`);
  });
});

app.listen(PORT, () => {
  console.log(`SSL Monitor running on http://0.0.0.0:${PORT}`);
  // Schedule cron after server starts
  setTimeout(scheduleCronJobs, 1000);
});
