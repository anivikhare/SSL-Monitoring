const { getDb } = require("./db");

function logActivity(userId, username, action, entityType = null, entityName = null, details = null, ip = null) {
  const db = getDb();
  db.run(
    `INSERT INTO activity_log (user_id, username, action, entity_type, entity_name, details, ip) VALUES (?,?,?,?,?,?,?)`,
    [userId, username, action, entityType, entityName, details, ip],
    (err) => { if (err) console.error("[ACTIVITY]", err.message); }
  );
}

module.exports = { logActivity };
