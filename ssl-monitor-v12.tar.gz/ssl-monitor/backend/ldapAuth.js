const ldap = require("ldapjs");
const { getSettings } = require("./mailer");

async function authenticateAD(adUsername, password) {
  let s;
  try {
    s = await getSettings();
  } catch (err) {
    console.error("[LDAP] Could not load settings:", err.message);
    return { success: false, error: "Could not load LDAP settings" };
  }

  if (s.ldap_enabled !== "true") {
    console.error("[LDAP] LDAP not enabled in settings");
    return { success: false, error: "LDAP not enabled" };
  }
  if (!s.ldap_url) {
    console.error("[LDAP] No LDAP URL configured");
    return { success: false, error: "LDAP URL not configured" };
  }
  if (!password) {
    return { success: false, error: "Password required" };
  }

  const domain = (s.ldap_domain || "").trim();
  const upn = adUsername.includes("@")
    ? adUsername
    : domain
    ? `${adUsername}@${domain}`
    : adUsername;

  console.log(`[LDAP] Attempting bind: ${upn} → ${s.ldap_url}`);

  return new Promise((resolve) => {
    let settled = false;

    const client = ldap.createClient({
      url: s.ldap_url,
      timeout: 10000,
      connectTimeout: 10000,
      tlsOptions: { rejectUnauthorized: false },
    });

    client.on("error", (err) => {
      console.error("[LDAP] Client error:", err.message);
      if (!settled) {
        settled = true;
        resolve({ success: false, error: `LDAP connection error: ${err.message}` });
      }
    });

    client.on("connectError", (err) => {
      console.error("[LDAP] Connect error:", err.message);
      if (!settled) {
        settled = true;
        resolve({ success: false, error: `Cannot reach LDAP server: ${err.message}` });
      }
    });

    client.bind(upn, password, (err) => {
      if (settled) return;
      settled = true;
      client.destroy();

      if (err) {
        console.error(`[LDAP] Bind failed for ${upn}:`, err.message, err.code);
        let msg = "Invalid credentials";
        if (err.message && err.message.includes("80090308")) msg = "Invalid AD credentials";
        else if (err.message && err.message.includes("533"))  msg = "Account disabled in AD";
        else if (err.message && err.message.includes("532"))  msg = "Password expired in AD";
        else if (err.message && err.message.includes("701"))  msg = "Account expired in AD";
        else if (err.message && err.message.includes("775"))  msg = "Account locked in AD";
        else msg = err.message || "AD authentication failed";
        resolve({ success: false, error: msg });
      } else {
        console.log(`[LDAP] Bind success for ${upn}`);
        resolve({ success: true });
      }
    });
  });
}

async function testLDAPConnection() {
  let s;
  try {
    s = await getSettings();
  } catch (err) {
    return { success: false, error: "Could not load settings" };
  }

  if (!s.ldap_url) return { success: false, error: "LDAP URL not configured" };

  return new Promise((resolve) => {
    let settled = false;

    const client = ldap.createClient({
      url: s.ldap_url,
      timeout: 8000,
      connectTimeout: 8000,
      tlsOptions: { rejectUnauthorized: false },
    });

    client.on("error", (err) => {
      if (!settled) {
        settled = true;
        resolve({ success: false, error: `Cannot reach LDAP server: ${err.message}` });
      }
    });

    client.on("connectError", (err) => {
      if (!settled) {
        settled = true;
        resolve({ success: false, error: `Connection failed: ${err.message}` });
      }
    });

    const bindDn = s.ldap_bind_dn || "";
    const bindPass = s.ldap_bind_pass || "";

    client.bind(bindDn, bindPass, (err) => {
      if (settled) return;
      settled = true;
      client.destroy();
      if (err) {
        resolve({ success: false, error: `Bind failed: ${err.message}` });
      } else {
        resolve({ success: true, message: `Connected to ${s.ldap_url} successfully` });
      }
    });
  });
}

module.exports = { authenticateAD, testLDAPConnection };
