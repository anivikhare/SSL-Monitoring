const tls    = require("tls");
const net    = require("net");
const tunnel = require("tunnel");
const { nowIST } = require("./timeHelper");

// Cooldown cache — prevents hammering the same proxy-routed FQDN repeatedly
const PROXY_COOLDOWN_MS = 30 * 1000;
const lastProxyCheck = new Map();

function getCooldownKey(fqdn, port) {
  return `${fqdn.toLowerCase()}:${port}`;
}

// Extract detailed info from a peer certificate
function extractCertDetails(cert, socket) {
  const details = {
    issuer: null,
    issuer_cn: null,
    subject_cn: null,
    san: null,
    valid_from: null,
    chain_valid: null,
    chain_error: null,
    protocol: null,
    cipher: null,
  };

  try {
    // Issuer — organization + common name
    if (cert.issuer) {
      details.issuer = cert.issuer.O || cert.issuer.CN || null;
      details.issuer_cn = cert.issuer.CN || null;
    }
    // Subject common name
    if (cert.subject) {
      details.subject_cn = cert.subject.CN || null;
    }
    // SAN list
    if (cert.subjectaltname) {
      details.san = cert.subjectaltname
        .split(",")
        .map(s => s.trim().replace(/^DNS:/, ""))
        .join(", ");
    }
    // Valid from
    if (cert.valid_from) {
      details.valid_from = new Date(cert.valid_from).toISOString().split("T")[0];
    }
    // Chain validation — check if the socket authorized the peer
    if (socket) {
      details.chain_valid = socket.authorized ? 1 : 0;
      details.chain_error = socket.authorizationError ? String(socket.authorizationError) : null;
      // Protocol + cipher
      const proto = socket.getProtocol ? socket.getProtocol() : null;
      details.protocol = proto || null;
      const cipher = socket.getCipher ? socket.getCipher() : null;
      details.cipher = cipher ? cipher.name : null;
    }
  } catch (e) { /* best effort */ }

  return details;
}

function buildResult(cert, socket, responseTimeMs) {
  const expiryDate = new Date(cert.valid_to);
  const now = new Date();
  const daysLeft = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));
  let status = daysLeft <= 0 ? "Expired" : daysLeft <= 14 ? "Critical" : daysLeft <= 30 ? "Warning" : "OK";
  const details = extractCertDetails(cert, socket);
  return {
    status,
    expiryDate: expiryDate.toISOString().split("T")[0],
    daysLeft,
    error: null,
    response_time_ms: responseTimeMs,
    ...details,
  };
}

// Empty details for error cases
const ERR_DETAILS = {
  response_time_ms: null, issuer: null, issuer_cn: null, subject_cn: null,
  san: null, valid_from: null, chain_valid: null, chain_error: null,
  protocol: null, cipher: null,
};

/**
 * Check SSL cert directly (no proxy)
 */
function checkSSLDirect(fqdn, port = 443) {
  return new Promise((resolve) => {
    const timeout = 10000;
    let resolved = false;
    const startTime = Date.now();

    const options = {
      host: fqdn,
      port: parseInt(port),
      servername: fqdn,
      rejectUnauthorized: false,
      timeout,
    };

    const socket = tls.connect(options, () => {
      const responseTimeMs = Date.now() - startTime;
      try {
        const cert = socket.getPeerCertificate(true);
        if (!cert || !cert.valid_to) {
          resolved = true; socket.destroy();
          return resolve({ status: "Error", expiryDate: null, daysLeft: null, error: "No certificate found", ...ERR_DETAILS });
        }
        const result = buildResult(cert, socket, responseTimeMs);
        resolved = true; socket.destroy();
        resolve(result);
      } catch (err) {
        resolved = true; socket.destroy();
        resolve({ status: "Error", expiryDate: null, daysLeft: null, error: err.message, ...ERR_DETAILS });
      }
    });

    socket.on("error", (err) => {
      if (!resolved) { resolved = true; resolve({ status: "Error", expiryDate: null, daysLeft: null, error: err.message, ...ERR_DETAILS }); }
    });
    socket.on("timeout", () => {
      if (!resolved) { resolved = true; socket.destroy(); resolve({ status: "Error", expiryDate: null, daysLeft: null, error: "Connection timed out", ...ERR_DETAILS }); }
    });
    socket.setTimeout(timeout);
  });
}

/**
 * Check SSL cert via HTTP CONNECT proxy tunnel
 */
function checkSSLViaProxy(fqdn, port = 443, proxyHost, proxyPort) {
  return new Promise((resolve) => {
    const timeout = 15000;
    let resolved = false;
    const startTime = Date.now();

    const done = (result) => {
      if (!resolved) { resolved = true; resolve(result); }
    };

    const proxySocket = net.connect(parseInt(proxyPort), proxyHost, () => {
      proxySocket.write(
        `CONNECT ${fqdn}:${port} HTTP/1.1\r\n` +
        `Host: ${fqdn}:${port}\r\n` +
        `User-Agent: curl/7.76.1\r\n` +
        `Proxy-Connection: Keep-Alive\r\n` +
        `Connection: Keep-Alive\r\n` +
        `\r\n`
      );
    });

    proxySocket.setTimeout(timeout);

    let buffer = "";
    proxySocket.on("data", (chunk) => {
      buffer += chunk.toString();
      if (!buffer.includes("\r\n\r\n")) return;

      const firstLine = buffer.split("\r\n")[0];
      if (!firstLine.includes("200")) {
        console.log(`[SSL] Proxy rejected ${fqdn}:${port} — full response:\n${buffer}`);
        proxySocket.destroy();
        let status = "Error";
        let error = `Proxy rejected: ${firstLine}`;
        if (firstLine.includes("403")) {
          status = "403 Proxy Blocked";
          error = "FQDN not whitelisted on proxy (403 Forbidden)";
        } else if (firstLine.includes("407")) {
          error = "Proxy authentication required (407)";
        } else if (firstLine.includes("502") || firstLine.includes("503")) {
          error = `Proxy gateway error: ${firstLine}`;
        }
        return done({ status, expiryDate: null, daysLeft: null, error, ...ERR_DETAILS });
      }

      const tlsSocket = tls.connect({
        socket: proxySocket,
        servername: fqdn,
        rejectUnauthorized: false,
      }, () => {
        const responseTimeMs = Date.now() - startTime;
        try {
          const cert = tlsSocket.getPeerCertificate(true);
          if (!cert || !cert.valid_to) {
            tlsSocket.destroy();
            return done({ status: "Error", expiryDate: null, daysLeft: null, error: "No certificate found", ...ERR_DETAILS });
          }
          const result = buildResult(cert, tlsSocket, responseTimeMs);
          tlsSocket.destroy();
          done(result);
        } catch (err) {
          tlsSocket.destroy();
          done({ status: "Error", expiryDate: null, daysLeft: null, error: err.message, ...ERR_DETAILS });
        }
      });

      tlsSocket.on("error", (err) => done({ status: "Error", expiryDate: null, daysLeft: null, error: `TLS error: ${err.message}`, ...ERR_DETAILS }));
    });

    proxySocket.on("error", (err) => done({ status: "Error", expiryDate: null, daysLeft: null, error: `Proxy connect error: ${err.message}`, ...ERR_DETAILS }));
    proxySocket.on("timeout", () => { proxySocket.destroy(); done({ status: "Error", expiryDate: null, daysLeft: null, error: "Proxy connection timed out", ...ERR_DETAILS }); });
  });
}

async function checkSSL(fqdn, port = 443, useProxy = false, proxyHost = "", proxyPort = "8080") {
  if (useProxy && proxyHost) {
    const key = getCooldownKey(fqdn, port);
    const cached = lastProxyCheck.get(key);
    const now = Date.now();

    if (cached && (now - cached.time) < PROXY_COOLDOWN_MS) {
      console.log(`[SSL] Cooldown active for ${fqdn}:${port} — returning cached result (${Math.round((PROXY_COOLDOWN_MS - (now - cached.time)) / 1000)}s remaining)`);
      return cached.result;
    }

    console.log(`[SSL] Checking ${fqdn}:${port} via proxy ${proxyHost}:${proxyPort}`);
    const result = await checkSSLViaProxy(fqdn, port, proxyHost, proxyPort);
    lastProxyCheck.set(key, { time: now, result });
    return result;
  }
  return checkSSLDirect(fqdn, port);
}

async function checkSSLBatch(fqdns, concurrency = 10, proxyHost = "", proxyPort = "8080") {
  const results = [];
  for (let i = 0; i < fqdns.length; i += concurrency) {
    const batch = fqdns.slice(i, i + concurrency);
    const batchResults = await Promise.all(
      batch.map(({ fqdn, port, use_proxy }) =>
        checkSSL(fqdn, port, !!use_proxy, proxyHost, proxyPort)
      )
    );
    results.push(...batchResults);
  }
  return results;
}

module.exports = { checkSSL, checkSSLBatch };
