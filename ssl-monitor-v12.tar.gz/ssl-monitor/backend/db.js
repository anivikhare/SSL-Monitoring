const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const DB_PATH = path.join(__dirname, "ssl_monitor.db");
let db;

function getDb() {
  if (!db) {
    // Enable foreign key enforcement (SQLite disables by default)
    db = new sqlite3.Database(DB_PATH, (err) => {
      db.run('PRAGMA foreign_keys = ON');
      if (err) {
        console.error("Error opening database:", err.message);
      } else {
        console.log("Connected to SQLite database");
        initializeDb();
      }
    });
  }
  return db;
}

function initializeDb() {
  db.serialize(() => {
    // Users — role: 'admin' | 'user', email used for login
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE,
        password TEXT,
        ad_username TEXT UNIQUE,
        auth_type TEXT NOT NULL DEFAULT 'local',
        role TEXT NOT NULL DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Projects
    db.run(`
      CREATE TABLE IF NOT EXISTS projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        alert_emails TEXT DEFAULT '',
        cc_emails TEXT DEFAULT '',
        deleted_at DATETIME DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Groups
    db.run(`
      CREATE TABLE IF NOT EXISTS groups (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        alert_emails TEXT DEFAULT '',
        cc_emails TEXT DEFAULT '',
        deleted_at DATETIME DEFAULT NULL,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      )
    `);

    // FQDNs — alert_sent tracks which thresholds have already been emailed (CSV e.g. "30,14")
    db.run(`
      CREATE TABLE IF NOT EXISTS fqdns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        fqdn TEXT NOT NULL,
        port INTEGER NOT NULL DEFAULT 443,
        network_type TEXT NOT NULL DEFAULT 'external',
        expiry_date TEXT,
        days_left INTEGER,
        status TEXT DEFAULT 'PENDING',
        last_checked DATETIME,
        alert_sent TEXT DEFAULT '',
        use_proxy INTEGER DEFAULT 0,
        last_error TEXT DEFAULT NULL,
        response_time_ms INTEGER DEFAULT NULL,
        issuer TEXT DEFAULT NULL,
        issuer_cn TEXT DEFAULT NULL,
        subject_cn TEXT DEFAULT NULL,
        san TEXT DEFAULT NULL,
        valid_from TEXT DEFAULT NULL,
        chain_valid INTEGER DEFAULT NULL,
        chain_error TEXT DEFAULT NULL,
        protocol TEXT DEFAULT NULL,
        cipher TEXT DEFAULT NULL,
        prev_expiry_date TEXT DEFAULT NULL,
        prev_issuer TEXT DEFAULT NULL,
        cert_changed_at TEXT DEFAULT NULL,
        deleted_at DATETIME DEFAULT NULL,
        FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE
      )
    `);

    // User-project assignments
    db.run(`
      CREATE TABLE IF NOT EXISTS user_projects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        project_id INTEGER NOT NULL,
        UNIQUE(user_id, project_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
      )
    `);

    // Settings — key/value store for SMTP config etc.
    db.run(`
      CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    `);

    // Migrations for existing installs
    db.run(`ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'`, () => {});
    db.run(`ALTER TABLE users ADD COLUMN email TEXT`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN alert_sent TEXT DEFAULT ''`, () => {});
    db.run(`ALTER TABLE projects ADD COLUMN alert_emails TEXT DEFAULT ''`, () => {});
    db.run(`ALTER TABLE projects ADD COLUMN cc_emails TEXT DEFAULT ''`, () => {});
    db.run(`ALTER TABLE groups ADD COLUMN cc_emails TEXT DEFAULT ''`, () => {});
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('global_cc', '')", () => {});
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('cron_ssl_check', '0 */6 * * *')", () => {});
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('daily_alert_days', '7')", () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN use_proxy INTEGER DEFAULT 0`, () => {});
    db.run(`ALTER TABLE projects ADD COLUMN deleted_at DATETIME DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE groups ADD COLUMN deleted_at DATETIME DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN deleted_at DATETIME DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE users ADD COLUMN last_login DATETIME DEFAULT NULL`, () => {});
    db.run(`CREATE TABLE IF NOT EXISTS activity_log (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, username TEXT NOT NULL, action TEXT NOT NULL, entity_type TEXT, entity_name TEXT, details TEXT, ip TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP)`, () => {});
    db.run(`CREATE TABLE IF NOT EXISTS reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      notes TEXT,
      remind_date TEXT NOT NULL,
      fqdn_id INTEGER DEFAULT NULL,
      project_id INTEGER DEFAULT NULL,
      email_to TEXT,
      email_cc TEXT,
      notified INTEGER DEFAULT 0,
      notified_thresholds TEXT DEFAULT '',
      done INTEGER DEFAULT 0,
      created_by TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`, () => {});
    db.run(`ALTER TABLE reminders ADD COLUMN notified_thresholds TEXT DEFAULT ''`, () => {});
    db.run(`ALTER TABLE reminders ADD COLUMN project_id INTEGER DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE reminders ADD COLUMN email_cc TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN last_error TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN response_time_ms INTEGER DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN issuer TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN issuer_cn TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN subject_cn TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN san TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN valid_from TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN chain_valid INTEGER DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN chain_error TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN protocol TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN cipher TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN prev_expiry_date TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN prev_issuer TEXT DEFAULT NULL`, () => {});
    db.run(`ALTER TABLE fqdns ADD COLUMN cert_changed_at TEXT DEFAULT NULL`, () => {});
    db.run(`CREATE UNIQUE INDEX IF NOT EXISTS idx_fqdns_unique ON fqdns(fqdn, port) WHERE deleted_at IS NULL`, () => {});
    db.run(`DELETE FROM fqdns WHERE group_id NOT IN (SELECT id FROM groups)`, () => {});
    db.run(`DELETE FROM fqdns WHERE group_id IN (SELECT id FROM groups WHERE project_id NOT IN (SELECT id FROM projects))`, () => {});
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('proxy_host', '')", () => {});
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('proxy_port', '8080')", () => {});
    db.run("INSERT OR IGNORE INTO settings (key, value) VALUES ('cron_alert', '0 8 * * *')", () => {});
    db.run(`ALTER TABLE users ADD COLUMN ad_username TEXT`, () => {});
    db.run(`ALTER TABLE users ADD COLUMN auth_type TEXT NOT NULL DEFAULT 'local'`, () => {});
    db.run(`ALTER TABLE groups ADD COLUMN alert_emails TEXT DEFAULT ''`, () => {});

    // Seed default SMTP settings (blank — admin fills in via UI)
    const defaultSettings = {
      smtp_host: "",
      smtp_port: "25",
      smtp_secure: "false",
      smtp_user: "",
      smtp_pass: "",
      smtp_from: "ssl-monitor@example.com",
      alerts_enabled: "false",
      daily_alert_days: "7",
      alert_thresholds: "30,14,7",
      global_cc: "",
      proxy_host: "",
      proxy_port: "8080",
      cron_ssl_check: "0 */6 * * *",
      cron_alert: "0 8 * * *",
      ldap_enabled: "false",
      ldap_url: "",
      ldap_base_dn: "",
      ldap_bind_dn: "",
      ldap_bind_pass: "",
      ldap_domain: "",
    };
    const settingsStmt = db.prepare(
      "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)"
    );
    Object.entries(defaultSettings).forEach(([k, v]) => settingsStmt.run(k, v));
    settingsStmt.finalize();

    // Seed default project
    db.get("SELECT id FROM projects WHERE name = 'JioGames'", (err, row) => {
      if (!row) {
        db.run("INSERT INTO projects (name) VALUES ('JioGames')", function () {
          db.run("INSERT INTO groups (project_id, name) VALUES (?, 'Jiogames')", [this.lastID]);
        });
      }
    });

    // Seed admin user
    const bcrypt = require("bcryptjs");
    db.get("SELECT id FROM users WHERE username = 'admin'", (err, row) => {
      if (!row) {
        const hash = bcrypt.hashSync("admin123", 10);
        db.run(
          "INSERT INTO users (username, email, password, role) VALUES ('admin', 'admin@example.com', ?, 'admin')",
          [hash]
        );
        console.log("Default admin created: username=admin password=admin123 email=admin@example.com");
      } else {
        db.run("UPDATE users SET role='admin' WHERE username='admin'");
      }
    });
  });
}

module.exports = { getDb };
