const express = require("express");
const { getDb } = require("../db");
const { authMiddleware, adminOnly } = require("../middleware");

const router = express.Router();
router.use(authMiddleware, adminOnly);

// GET all soft-deleted items
router.get("/", (req, res) => {
  const db = getDb();

  const result = { projects: [], groups: [], fqdns: [] };
  let pending = 3;
  const done = () => { if (--pending === 0) res.json(result); };

  db.all(
    `SELECT p.*, 'project' as type FROM projects p
     WHERE p.deleted_at IS NOT NULL
     ORDER BY p.deleted_at DESC`,
    (err, rows) => { if (!err) result.projects = rows; done(); }
  );

  db.all(
    `SELECT g.*, p.name as project_name, 'group' as type FROM groups g
     JOIN projects p ON p.id = g.project_id
     WHERE g.deleted_at IS NOT NULL
     ORDER BY g.deleted_at DESC`,
    (err, rows) => { if (!err) result.groups = rows; done(); }
  );

  db.all(
    `SELECT f.*, g.name as group_name, p.name as project_name, 'fqdn' as type
     FROM fqdns f
     JOIN groups g ON g.id = f.group_id
     JOIN projects p ON p.id = g.project_id
     WHERE f.deleted_at IS NOT NULL
     ORDER BY f.deleted_at DESC`,
    (err, rows) => { if (!err) result.fqdns = rows; done(); }
  );
});

// GET trash count (for badge)
router.get("/count", (req, res) => {
  const db = getDb();
  db.all(
    `SELECT
      (SELECT COUNT(*) FROM projects WHERE deleted_at IS NOT NULL) +
      (SELECT COUNT(*) FROM groups WHERE deleted_at IS NOT NULL) +
      (SELECT COUNT(*) FROM fqdns WHERE deleted_at IS NOT NULL) as total`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ count: rows[0]?.total || 0 });
    }
  );
});

// POST restore item
router.post("/restore/:type/:id", (req, res) => {
  const { type, id } = req.params;
  const db = getDb();

  const tables = { project: "projects", group: "groups", fqdn: "fqdns" };
  const table = tables[type];
  if (!table) return res.status(400).json({ error: "Invalid type" });

  db.run(
    `UPDATE ${table} SET deleted_at=NULL WHERE id=?`,
    [id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });

      // Restore child items if restoring project or group
      if (type === "project") {
        db.run("UPDATE groups SET deleted_at=NULL WHERE project_id=? AND deleted_at IS NOT NULL", [id]);
        db.run(`UPDATE fqdns SET deleted_at=NULL WHERE group_id IN
          (SELECT id FROM groups WHERE project_id=?) AND deleted_at IS NOT NULL`, [id]);
      }
      if (type === "group") {
        db.run("UPDATE fqdns SET deleted_at=NULL WHERE group_id=? AND deleted_at IS NOT NULL", [id]);
      }

      res.json({ restored: this.changes });
    }
  );
});

// DELETE empty trash (permanent delete all)
router.delete("/empty", (req, res) => {
  const db = getDb();
  db.serialize(() => {
    db.run("DELETE FROM fqdns WHERE deleted_at IS NOT NULL");
    db.run("DELETE FROM groups WHERE deleted_at IS NOT NULL");
    db.run("DELETE FROM projects WHERE deleted_at IS NOT NULL", function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: "Trash emptied" });
    });
  });
});

// DELETE permanently delete item
router.delete("/:type/:id", (req, res) => {
  const { type, id } = req.params;
  const db = getDb();
  const tables = { project: "projects", group: "groups", fqdn: "fqdns" };
  const table = tables[type];
  if (!table) return res.status(400).json({ error: "Invalid type" });

  db.run(`DELETE FROM ${table} WHERE id=? AND deleted_at IS NOT NULL`, [id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ deleted: this.changes });
  });
});


module.exports = router;
