const express = require("express");
const { getDb } = require("../db");
const { authMiddleware, adminOnly, notReadonly } = require("../middleware");
const { logActivity } = require("../activityLog");

const router = express.Router();
router.use(authMiddleware);

// GET all reminders (with optional fqdn join for display)
router.get("/", (req, res) => {
  const db = getDb();
  db.all(
    `SELECT r.*, f.fqdn AS fqdn_name, p.name AS project_name
     FROM reminders r
     LEFT JOIN fqdns f ON f.id = r.fqdn_id
     LEFT JOIN projects p ON p.id = r.project_id
     ORDER BY r.done ASC, r.remind_date ASC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// GET upcoming/due reminders for dashboard banner (not done, within 7 days or overdue)
router.get("/active", (req, res) => {
  const db = getDb();
  db.all(
    `SELECT r.*, f.fqdn AS fqdn_name, p.name AS project_name
     FROM reminders r
     LEFT JOIN fqdns f ON f.id = r.fqdn_id
     LEFT JOIN projects p ON p.id = r.project_id
     WHERE r.done = 0
       AND date(r.remind_date) <= date('now', '+7 days')
     ORDER BY r.remind_date ASC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// POST create reminder
router.post("/", notReadonly, (req, res) => {
  const { title, notes = "", remind_date, fqdn_id = null, project_id = null, email_to = "", email_cc = "" } = req.body;
  if (!title || !remind_date) return res.status(400).json({ error: "Title and date required" });
  const db = getDb();
  db.run(
    `INSERT INTO reminders (title, notes, remind_date, fqdn_id, project_id, email_to, email_cc, created_by) VALUES (?,?,?,?,?,?,?,?)`,
    [title.trim(), notes, remind_date, fqdn_id || null, project_id || null, email_to, email_cc, req.user.username],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      logActivity(req.user.id, req.user.username, "CREATE", "reminder", title.trim());
      res.json({ id: this.lastID });
    }
  );
});

// PUT update reminder
router.put("/:id", notReadonly, (req, res) => {
  const { title, notes, remind_date, fqdn_id, project_id, email_to, email_cc, done } = req.body;
  const db = getDb();
  db.run(
    `UPDATE reminders SET title=?, notes=?, remind_date=?, fqdn_id=?, project_id=?, email_to=?, email_cc=?, done=?,
       notified=CASE WHEN remind_date != ? THEN 0 ELSE notified END,
       notified_thresholds=CASE WHEN remind_date != ? THEN '' ELSE notified_thresholds END
     WHERE id=?`,
    [title, notes || "", remind_date, fqdn_id || null, project_id || null, email_to || "", email_cc || "", done ? 1 : 0, remind_date, remind_date, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ updated: this.changes });
    }
  );
});

// PATCH mark done / undone
router.patch("/:id/done", notReadonly, (req, res) => {
  const db = getDb();
  db.run("UPDATE reminders SET done=? WHERE id=?", [req.body.done ? 1 : 0, req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ updated: this.changes });
  });
});

// DELETE reminder
router.delete("/:id", notReadonly, (req, res) => {
  const db = getDb();
  db.run("DELETE FROM reminders WHERE id=?", [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
