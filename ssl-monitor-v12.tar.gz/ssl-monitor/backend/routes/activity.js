const express = require("express");
const { getDb } = require("../db");
const { authMiddleware, adminOnly } = require("../middleware");

const router = express.Router();
router.use(authMiddleware, adminOnly);

// GET activity log — paginated, filterable
router.get("/", (req, res) => {
  const { page = 1, limit = 50, user, action, entity_type } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  const db = getDb();

  let where = "WHERE 1=1";
  const params = [];
  if (user)        { where += " AND username LIKE ?"; params.push(`%${user}%`); }
  if (action)      { where += " AND action = ?"; params.push(action); }
  if (entity_type) { where += " AND entity_type = ?"; params.push(entity_type); }

  db.get(`SELECT COUNT(*) as total FROM activity_log ${where}`, params, (err, countRow) => {
    if (err) return res.status(500).json({ error: err.message });
    db.all(
      `SELECT * FROM activity_log ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset],
      (err2, rows) => {
        if (err2) return res.status(500).json({ error: err2.message });
        res.json({ total: countRow.total, page: parseInt(page), limit: parseInt(limit), logs: rows });
      }
    );
  });
});

// DELETE clear all logs — admin only
router.delete("/", (req, res) => {
  const db = getDb();
  db.run("DELETE FROM activity_log", function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
