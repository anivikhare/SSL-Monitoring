const express = require("express");
const { nowIST } = require("../timeHelper");
const { getDb } = require("../db");
const { authMiddleware, adminOnly } = require("../middleware");

const router = express.Router();
router.use(authMiddleware);

// Helper: fetch full project tree for given project IDs
function fetchProjectsByIds(db, projectIds, res) {
  if (!projectIds.length) return res.json([]);

  const placeholders = projectIds.map(() => "?").join(",");
  db.all(`SELECT * FROM projects WHERE id IN (${placeholders}) AND deleted_at IS NULL`, projectIds, (err, projects) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!projects.length) return res.json([]);

    db.all(`SELECT * FROM groups WHERE project_id IN (${placeholders}) AND deleted_at IS NULL`, projectIds, (err2, groups) => {
      if (err2) return res.status(500).json({ error: err2.message });

      const groupIds = groups.map((g) => g.id);
      if (!groupIds.length) {
        return res.json(projects.map((p) => ({ ...p, groups: [] })));
      }

      const gPlaceholders = groupIds.map(() => "?").join(",");
      db.all(`SELECT * FROM fqdns WHERE group_id IN (${gPlaceholders}) AND deleted_at IS NULL`, groupIds, (err3, fqdns) => {
        if (err3) return res.status(500).json({ error: err3.message });
        const result = projects.map((project) => ({
          ...project,
          groups: groups
            .filter((g) => g.project_id === project.id)
            .map((group) => ({
              ...group,
              fqdns: fqdns.filter((f) => f.group_id === group.id),
            })),
        }));
        res.json(result);
      });
    });
  });
}

// GET all projects — admin gets all, normal user gets only assigned
router.get("/", (req, res) => {
  const db = getDb();
  if (req.user.role === "admin") {
    db.all("SELECT id FROM projects WHERE deleted_at IS NULL", (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      fetchProjectsByIds(db, rows.map((r) => r.id), res);
    });
  } else {
    db.all(
      "SELECT project_id FROM user_projects WHERE user_id = ?",
      [req.user.id],
      (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        fetchProjectsByIds(db, rows.map((r) => r.project_id), res);
      }
    );
  }
});

// Create project — admin only
router.post("/", adminOnly, (req, res) => {
  const { name, alert_emails = "", cc_emails = "" } = req.body;
  if (!name) return res.status(400).json({ error: "Project name required" });
  const db = getDb();
  db.run("INSERT INTO projects (name, alert_emails, cc_emails) VALUES (?, ?, ?)", [name, alert_emails, cc_emails], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    logActivity(req.user.id, req.user.username, "CREATE", "project", name);
    res.json({ id: this.lastID, name, alert_emails, cc_emails });
  });
});

// Update project (rename + alert_emails) — admin only
router.put("/:id", adminOnly, (req, res) => {
  const { name, alert_emails, cc_emails } = req.body;
  if (!name) return res.status(400).json({ error: "Project name required" });
  const db = getDb();
  db.run(
    "UPDATE projects SET name=?, alert_emails=?, cc_emails=? WHERE id=?",
    [name.trim(), alert_emails || "", cc_emails || "", req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      if (!this.changes) return res.status(404).json({ error: "Project not found" });
      logActivity(req.user.id, req.user.username, "UPDATE", "project", name.trim());
      res.json({ id: parseInt(req.params.id), name: name.trim(), alert_emails, cc_emails });
    }
  );
});

// Delete project — admin only
router.delete("/:id", adminOnly, (req, res) => {
  const db = getDb();
  db.run("UPDATE projects SET deleted_at=? WHERE id=? AND deleted_at IS NULL", [nowIST(), req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    db.run("UPDATE groups SET deleted_at=? WHERE project_id=? AND deleted_at IS NULL", [nowIST(), req.params.id]);
    db.run("UPDATE fqdns SET deleted_at=? WHERE group_id IN (SELECT id FROM groups WHERE project_id=?) AND deleted_at IS NULL", [nowIST(), req.params.id]);
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
