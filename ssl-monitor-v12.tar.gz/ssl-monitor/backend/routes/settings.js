const express = require("express");
const { getDb } = require("../db");
const { authMiddleware, adminOnly } = require("../middleware");
const { sendTestEmail, getSettings } = require("../mailer");
const { testLDAPConnection } = require("../ldapAuth");

const router = express.Router();
router.use(authMiddleware, adminOnly);

const ALLOWED_KEYS = [
  "smtp_host", "smtp_port", "smtp_secure", "smtp_user", "smtp_pass",
  "smtp_from", "alerts_enabled", "alert_thresholds", "daily_alert_days",
  "global_cc",
  "proxy_host", "proxy_port",
  "cron_ssl_check", "cron_alert",
  "ldap_enabled", "ldap_url", "ldap_base_dn", "ldap_bind_dn", "ldap_bind_pass", "ldap_domain",
];

// GET all settings (mask passwords)
router.get("/", async (req, res) => {
  try {
    const s = await getSettings();
    if (s.smtp_pass) s.smtp_pass = "••••••••";
    if (s.ldap_bind_pass) s.ldap_bind_pass = "••••••••";
    res.json(s);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH update settings
router.patch("/", (req, res) => {
  const updates = req.body;
  const db = getDb();
  const stmt = db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)");
  let count = 0;
  let cronChanged = false;
  for (const [key, value] of Object.entries(updates)) {
    if (!ALLOWED_KEYS.includes(key)) continue;
    if (key === "smtp_pass" && value === "••••••••") continue;
    if (key === "ldap_bind_pass" && value === "••••••••") continue;
    stmt.run(key, String(value));
    count++;
    if (key === "cron_ssl_check" || key === "cron_alert") cronChanged = true;
  }
  stmt.finalize(() => {
    // Reschedule cron if cron settings changed
    if (cronChanged) {
      const http = require("http");
      const req2 = http.request({ host: "localhost", port: process.env.PORT || 8000, path: "/api/internal/reschedule", method: "POST" });
      req2.on("error", () => {});
      req2.end();
    }
  });
  res.json({ updated: count });
});

// POST test SMTP
router.post("/test-email", async (req, res) => {
  try {
    const { to } = req.body;
    await sendTestEmail(to);
    res.json({ message: "Test email sent successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET cron status — next run times
router.get("/cron-status", async (req, res) => {
  try {
    const s = await getSettings();
    const sslExpr   = s.cron_ssl_check || "0 */6 * * *";
    const alertExpr = s.cron_alert     || "30 2 * * *";

    // Calculate next run using simple cron-parser logic
    const cronParser = require("node-cron");

    res.json({
      ssl_check:  { expr: sslExpr,   valid: cronParser.validate(sslExpr) },
      alert:      { expr: alertExpr, valid: cronParser.validate(alertExpr) },
      server_time: new Date().toISOString(),
      server_time_ist: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }) + " IST",
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST run alert now manually (force=true ignores alert_sent flags)
router.post("/run-alert", async (req, res) => {
  try {
    const { sendExpiryAlerts } = require("../mailer");
    const result = await sendExpiryAlerts(true); // force send
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST test LDAP connection
router.post("/test-ldap", async (req, res) => {
  try {
    const result = await testLDAPConnection();
    if (result.success) res.json({ message: result.message });
    else res.status(400).json({ error: result.error });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
