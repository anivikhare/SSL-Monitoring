const express = require("express");
const { nowIST } = require("../timeHelper");
const { buildFqdnUpdate } = require("../updateFqdn");
const { getDb } = require("../db");
const { authMiddleware, adminOnly, notReadonly } = require("../middleware");
const { checkSSL, checkSSLBatch } = require("../sslChecker");
const { logActivity } = require("../activityLog");
const { getSettings } = require("../mailer");

const router = express.Router();
router.use(authMiddleware);

// Helper: verify normal user is assigned to the project that owns this group
function userCanAccessGroup(db, userId, groupId, callback) {
  db.get(
    `SELECT g.id FROM groups g
     JOIN user_projects up ON up.project_id = g.project_id
     WHERE g.id = ? AND up.user_id = ?`,
    [groupId, userId],
    (err, row) => callback(!!row)
  );
}

// Add FQDN — admin always, normal user only if assigned to the project
router.post("/", notReadonly, (req, res) => {
  const { group_id, fqdn, port = 443, network_type = "external" } = req.body;
  if (!group_id || !fqdn)
    return res.status(400).json({ error: "group_id and fqdn required" });

  const db = getDb();

  const doInsert = () => {
    db.run(
      `INSERT INTO fqdns (group_id, fqdn, port, network_type, use_proxy, status) VALUES (?, ?, ?, ?, ?, 'PENDING')`,
      [group_id, fqdn.trim(), port, network_type, req.body.use_proxy ? 1 : 0],
      function (err) {
        if (err) {
      if (err.message.includes("UNIQUE")) return res.status(409).json({ error: `${fqdn}:${port} already exists in another group` });
      return res.status(500).json({ error: err.message });
    }
        const id = this.lastID;
        getSettings().then(s => {
          checkSSL(fqdn.trim(), port, !!req.body.use_proxy, s.proxy_host || "", s.proxy_port || "8080").then((result) => {
            const u = buildFqdnUpdate(result, id);
            db.run(u.sql, u.params);
          });
        });
        logActivity(req.user.id, req.user.username, "ADD_FQDN", "fqdn", fqdn.trim(), `port:${port}`);
        res.json({ id, group_id, fqdn, port, network_type, use_proxy: req.body.use_proxy ? 1 : 0, status: "PENDING" });
      }
    );
  };

  if (req.user.role === "admin") {
    doInsert();
  } else {
    userCanAccessGroup(db, req.user.id, group_id, (allowed) => {
      if (!allowed)
        return res.status(403).json({ error: "You are not assigned to this project" });
      doInsert();
    });
  }
});

// Edit FQDN — admin only
router.put("/:id", adminOnly, (req, res) => {
  const { fqdn, port, network_type } = req.body;
  if (!fqdn) return res.status(400).json({ error: "FQDN required" });
  const db = getDb();
  db.run(
    `UPDATE fqdns SET fqdn=?, port=?, network_type=?, use_proxy=?, status='PENDING',
     expiry_date=NULL, days_left=NULL, last_checked=NULL WHERE id=?`,
    [fqdn.trim(), port || 443, network_type || "external", req.body.use_proxy ? 1 : 0, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      if (!this.changes) return res.status(404).json({ error: "FQDN not found" });
      // Trigger SSL check on updated FQDN
      const { checkSSL } = require("../sslChecker");
      getSettings().then(s => {
        checkSSL(fqdn.trim(), port || 443, req.body.use_proxy, s.proxy_host || "", s.proxy_port || "8080").then((r) => {
          const u = buildFqdnUpdate(r, req.params.id);
          db.run(u.sql, u.params);
        });
      });
      res.json({ id: parseInt(req.params.id), fqdn: fqdn.trim(), port, network_type });
    }
  );
});

// Delete FQDN — admin only (soft delete)
router.delete("/:id", adminOnly, (req, res) => {
  const db = getDb();
  db.get("SELECT fqdn FROM fqdns WHERE id=?", [req.params.id], (e, row) => {
    db.run("UPDATE fqdns SET deleted_at=CURRENT_TIMESTAMP WHERE id=? AND deleted_at IS NULL", [req.params.id], function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ deleted: this.changes });
    });
  });
});

// Check single FQDN — any authenticated user except readonly
router.post("/:id/check", notReadonly, (req, res) => {
  const db = getDb();
  db.get("SELECT * FROM fqdns WHERE id = ?", [req.params.id], async (err, row) => {
    if (err || !row) return res.status(404).json({ error: "FQDN not found" });

    const doCheck = async () => {
      const s = await getSettings().catch(() => ({}));
      const result = await checkSSL(row.fqdn, row.port, !!row.use_proxy, s.proxy_host || "", s.proxy_port || "8080");
      const u = buildFqdnUpdate(result, row.id, row);
      db.run(u.sql, u.params,
        (err2) => {
          if (err2) return res.status(500).json({ error: err2.message });
          res.json({
            id: row.id, fqdn: row.fqdn,
            status: result.status, expiry_date: result.expiryDate,
            days_left: result.daysLeft, last_error: result.error || null,
          });
        }
      );
    };

    if (req.user.role === "admin") {
      doCheck();
    } else {
      userCanAccessGroup(db, req.user.id, row.group_id, (allowed) => {
        if (!allowed)
          return res.status(403).json({ error: "Access denied" });
        doCheck();
      });
    }
  });
});

// Check all — admin only
router.post("/check-all", adminOnly, async (req, res) => {
  const db = getDb();
  db.all("SELECT * FROM fqdns WHERE deleted_at IS NULL", async (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!rows.length) return res.json({ message: "No FQDNs to check", updated: 0 });

    res.json({ message: "SSL check started", total: rows.length });

    const s = await getSettings().catch(() => ({}));
    const results = await checkSSLBatch(rows, 10, s.proxy_host || "", s.proxy_port || "8080");
    rows.forEach((row, i) => {
      const r = results[i];
      const u = buildFqdnUpdate(r, row.id);
      db.run(u.sql, u.params);
    });
    stmt.finalize();
  });
});

// POST bulk import FQDNs from CSV/text
router.post("/bulk-import", adminOnly, async (req, res) => {
  const { group_id, entries } = req.body;
  // entries: [{ fqdn, port, network_type, use_proxy }]
  if (!group_id || !entries || !entries.length)
    return res.status(400).json({ error: "group_id and entries required" });

  const db = getDb();

  // Get all existing FQDNs for duplicate detection
  db.all("SELECT fqdn, port FROM fqdns WHERE deleted_at IS NULL", async (err, existing) => {
    if (err) return res.status(500).json({ error: err.message });

    const existingSet = new Set(existing.map(f => `${f.fqdn.toLowerCase()}:${f.port}`));
    const s = await getSettings().catch(() => ({}));

    const results = { imported: [], duplicates: [], errors: [] };

    const stmt = db.prepare(
      `INSERT INTO fqdns (group_id, fqdn, port, network_type, use_proxy, status) VALUES (?, ?, ?, ?, ?, 'PENDING')`
    );

    for (const entry of entries) {
      const fqdn = (entry.fqdn || "").trim().toLowerCase();
      const port = parseInt(entry.port) || 443;
      const network_type = entry.network_type || "external";
      const use_proxy = entry.use_proxy ? 1 : 0;

      if (!fqdn) continue;

      // Duplicate check
      if (existingSet.has(`${fqdn}:${port}`)) {
        results.duplicates.push({ fqdn, port, reason: "Already exists in another project/group" });
        continue;
      }

      try {
        await new Promise((resolve, reject) => {
          stmt.run([group_id, fqdn, port, network_type, use_proxy], function(e) {
            if (e) { results.errors.push({ fqdn, error: e.message }); reject(e); }
            else {
              const id = this.lastID;
              existingSet.add(`${fqdn}:${port}`); // prevent dupes within same import
              results.imported.push({ id, fqdn, port, network_type });
              // Trigger SSL check async
              checkSSL(fqdn, port, !!use_proxy, s.proxy_host || "", s.proxy_port || "8080").then(r => {
                const bu = buildFqdnUpdate(r, id);
                db.run(bu.sql, bu.params);
              });
              resolve();
            }
          });
        });
      } catch (e) { /* already pushed to errors */ }
    }

    stmt.finalize();
    const { logActivity } = require("../activityLog");
    logActivity(req.user.id, req.user.username, "BULK_IMPORT", "fqdn",
      `${results.imported.length} FQDNs`, `group_id:${group_id}`);
    res.json(results);
  });
});

// POST bulk re-check — takes array of ids
router.post("/bulk-recheck", notReadonly, async (req, res) => {
  const { ids } = req.body;
  if (!ids || !ids.length) return res.status(400).json({ error: "ids required" });
  const db = getDb();
  const s = await getSettings().catch(() => ({}));
  const placeholders = ids.map(() => "?").join(",");
  db.all(`SELECT * FROM fqdns WHERE id IN (${placeholders}) AND deleted_at IS NULL`, ids, async (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    // Fire checks in background, respond immediately
    res.json({ rechecking: rows.length });
    for (const row of rows) {
      checkSSL(row.fqdn, row.port, !!row.use_proxy, s.proxy_host || "", s.proxy_port || "8080").then(r => {
        const u = buildFqdnUpdate(r, row.id, row);
        db.run(u.sql, u.params);
      });
    }
  });
});

// POST bulk delete (soft) — takes array of ids
router.post("/bulk-delete", adminOnly, (req, res) => {
  const { ids } = req.body;
  if (!ids || !ids.length) return res.status(400).json({ error: "ids required" });
  const db = getDb();
  const { nowIST } = require("../timeHelper");
  const placeholders = ids.map(() => "?").join(",");
  db.run(
    `UPDATE fqdns SET deleted_at=? WHERE id IN (${placeholders}) AND deleted_at IS NULL`,
    [nowIST(), ...ids],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      const { logActivity } = require("../activityLog");
      logActivity(req.user.id, req.user.username, "BULK_DELETE", "fqdn", `${this.changes} FQDNs`);
      res.json({ deleted: this.changes });
    }
  );
});

module.exports = router;
