const express = require("express");
const { nowIST } = require("../timeHelper");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { getDb } = require("../db");
const { logActivity } = require("../activityLog");
const { authMiddleware, adminOnly, JWT_SECRET } = require("../middleware");
const { authenticateAD } = require("../ldapAuth");

const router = express.Router();

// ── Login ─────────────────────────────────────────────────────────────────────
// admin → always local password
// other users → LDAP/AD if auth_type='ldap', else local
router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password)
    return res.status(400).json({ error: "Username/email and password required" });

  const db = getDb();

  db.get(
    "SELECT * FROM users WHERE username=? OR LOWER(email)=LOWER(?) OR LOWER(ad_username)=LOWER(?)",
    [username, username, username],
    async (err, user) => {
      if (err || !user)
        return res.status(401).json({ error: "Invalid credentials" });

      let authenticated = false;

      if (user.auth_type === "ldap") {
        // LDAP/AD auth — applies to any role including admin if set to ldap
        const adUser = user.ad_username || user.username;
        const result = await authenticateAD(adUser, password);
        if (!result.success)
          return res.status(401).json({ error: result.error || "AD authentication failed" });
        authenticated = true;
      } else {
        // Local password auth
        if (!user.password)
          return res.status(401).json({ error: "No local password set for this user" });
        authenticated = bcrypt.compareSync(password, user.password);
      }

      if (!authenticated)
        return res.status(401).json({ error: "Invalid credentials" });

      const token = jwt.sign(
        { id: user.id, username: user.username, role: user.role, email: user.email },
        JWT_SECRET,
        { expiresIn: "8h" }
      );
      // Track last login and log activity
      db.run("UPDATE users SET last_login=? WHERE id=?", [nowIST(), user.id]);
      const { logActivity } = require("../activityLog");
      let ip = req.headers["x-forwarded-for"] || req.socket?.remoteAddress || null;
      // x-forwarded-for may be a comma list; take the first, and strip IPv4-mapped IPv6 prefix
      if (ip) {
        ip = ip.split(",")[0].trim().replace(/^::ffff:/, "");
        if (ip === "::1") ip = "127.0.0.1";
      }
      logActivity(user.id, user.username, "LOGIN", "user", user.username, null, ip);
      res.json({ token, username: user.username, role: user.role, email: user.email });
    }
  );
});

// ── Change own password (local users only) ────────────────────────────────────
router.post("/change-password", authMiddleware, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword)
    return res.status(400).json({ error: "Both passwords required" });

  const db = getDb();
  db.get("SELECT * FROM users WHERE id=?", [req.user.id], (err, user) => {
    if (err || !user) return res.status(404).json({ error: "User not found" });
    if (user.auth_type === "ldap")
      return res.status(400).json({ error: "LDAP users must change password in Active Directory" });
    if (!bcrypt.compareSync(currentPassword, user.password))
      return res.status(401).json({ error: "Current password incorrect" });
    const hash = bcrypt.hashSync(newPassword, 10);
    db.run("UPDATE users SET password=? WHERE id=?", [hash, user.id], (err2) => {
      if (err2) return res.status(500).json({ error: "Failed to update password" });
      res.json({ message: "Password updated successfully" });
    });
  });
});

// ── Admin: list all users ─────────────────────────────────────────────────────
router.get("/users", authMiddleware, adminOnly, (req, res) => {
  const db = getDb();
  db.all(
    `SELECT u.id, u.username, u.email, u.role, u.auth_type, u.ad_username, u.created_at, u.last_login,
       GROUP_CONCAT(up.project_id) AS project_ids
     FROM users u
     LEFT JOIN user_projects up ON up.user_id = u.id
     GROUP BY u.id
     ORDER BY u.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows.map((r) => ({ last_login: r.last_login,
        ...r,
        project_ids: r.project_ids ? r.project_ids.split(",").map(Number) : [],
      })));
    }
  );
});

// ── Admin: create user ────────────────────────────────────────────────────────
router.post("/users", authMiddleware, adminOnly, (req, res) => {
  const { username, email, password, role = "user", auth_type = "local", ad_username, project_ids = [] } = req.body;

  if (!username) return res.status(400).json({ error: "Username required" });
  if (auth_type === "local" && !password)
    return res.status(400).json({ error: "Password required for local users" });
  if (auth_type === "ldap" && !ad_username)
    return res.status(400).json({ error: "AD username required for LDAP users" });
  if (!["admin", "user", "readonly"].includes(role))
    return res.status(400).json({ error: "Invalid role" });
  if (!["local", "ldap"].includes(auth_type))
    return res.status(400).json({ error: "auth_type must be local or ldap" });

  const db = getDb();
  const hash = auth_type === "local" ? bcrypt.hashSync(password, 10) : null;

  db.run(
    "INSERT INTO users (username, email, password, role, auth_type, ad_username) VALUES (?,?,?,?,?,?)",
    [username, email || null, hash, role, auth_type, ad_username || null],
    function (err) {
      if (err) {
        if (err.message.includes("UNIQUE"))
          return res.status(409).json({ error: "Username, email or AD username already exists" });
        return res.status(500).json({ error: err.message });
      }
      const userId = this.lastID;
      if (project_ids.length > 0) {
        const stmt = db.prepare("INSERT OR IGNORE INTO user_projects (user_id, project_id) VALUES (?,?)");
        project_ids.forEach((pid) => stmt.run(userId, pid));
        stmt.finalize();
      }
      res.json({ id: userId, username, email, role, auth_type, ad_username, project_ids });
    }
  );
});

// ── Admin: update user ────────────────────────────────────────────────────────
router.put("/users/:id", authMiddleware, adminOnly, (req, res) => {
  const { password, email, role, ad_username, auth_type, project_ids } = req.body;
  const db = getDb();
  const userId = parseInt(req.params.id);

  if (role && !["admin", "user", "readonly"].includes(role))
    return res.status(400).json({ error: "Invalid role" });
  if (role && role !== "admin" && req.user.id === userId)
    return res.status(400).json({ error: "Cannot change your own role" });

  const finish = () => {
    if (project_ids !== undefined) {
      db.run("DELETE FROM user_projects WHERE user_id=?", [userId], () => {
        if (project_ids.length > 0) {
          const stmt = db.prepare("INSERT OR IGNORE INTO user_projects (user_id, project_id) VALUES (?,?)");
          project_ids.forEach((pid) => stmt.run(userId, pid));
          stmt.finalize();
        }
        res.json({ message: "User updated" });
      });
    } else {
      res.json({ message: "User updated" });
    }
  };

  const fields = [];
  const vals = [];
  if (password) { fields.push("password=?"); vals.push(bcrypt.hashSync(password, 10)); }
  if (email !== undefined) { fields.push("email=?"); vals.push(email || null); }
  if (role) { fields.push("role=?"); vals.push(role); }
  if (ad_username !== undefined) { fields.push("ad_username=?"); vals.push(ad_username || null); }
  if (auth_type) { fields.push("auth_type=?"); vals.push(auth_type); }

  if (fields.length > 0) {
    vals.push(userId);
    db.run(`UPDATE users SET ${fields.join(",")} WHERE id=?`, vals, finish);
  } else {
    finish();
  }
});

// ── Admin: delete user ────────────────────────────────────────────────────────
router.delete("/users/:id", authMiddleware, adminOnly, (req, res) => {
  const db = getDb();
  db.get("SELECT role FROM users WHERE id=?", [req.params.id], (err, row) => {
    if (!row) return res.status(404).json({ error: "User not found" });
    if (row.role === "admin" && req.user.id === parseInt(req.params.id))
      return res.status(400).json({ error: "Cannot delete yourself" });
    db.run("DELETE FROM users WHERE id=?", [req.params.id], function (err2) {
      if (err2) return res.status(500).json({ error: err2.message });
      res.json({ deleted: this.changes });
    });
  });
});

module.exports = router;
