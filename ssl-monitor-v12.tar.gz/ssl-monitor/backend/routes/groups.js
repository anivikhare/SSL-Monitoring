const express = require("express");
const { getDb } = require("../db");
const { authMiddleware, adminOnly } = require("../middleware");

const router = express.Router();
router.use(authMiddleware);

// Create group — admin only
router.post("/", adminOnly, (req, res) => {
  const { project_id, name, alert_emails = "", cc_emails = "" } = req.body;
  if (!project_id || !name)
    return res.status(400).json({ error: "project_id and name required" });
  const db = getDb();
  db.run(
    "INSERT INTO groups (project_id, name, alert_emails, cc_emails) VALUES (?, ?, ?, ?)",
    [project_id, name, alert_emails, cc_emails],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, project_id, name, alert_emails, cc_emails });
    }
  );
});

// Update group (rename + alert_emails) — admin only
router.put("/:id", adminOnly, (req, res) => {
  const { name, alert_emails, cc_emails } = req.body;
  if (!name) return res.status(400).json({ error: "Group name required" });
  const db = getDb();
  db.run(
    "UPDATE groups SET name=?, alert_emails=?, cc_emails=? WHERE id=?",
    [name.trim(), alert_emails || "", cc_emails || "", req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      if (!this.changes) return res.status(404).json({ error: "Group not found" });
      res.json({ id: parseInt(req.params.id), name: name.trim(), alert_emails, cc_emails });
    }
  );
});

// Delete group — admin only (soft delete)
router.delete("/:id", adminOnly, (req, res) => {
  const db = getDb();
  db.run("UPDATE groups SET deleted_at=CURRENT_TIMESTAMP WHERE id=? AND deleted_at IS NULL", [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    db.run("UPDATE fqdns SET deleted_at=CURRENT_TIMESTAMP WHERE group_id=? AND deleted_at IS NULL", [req.params.id]);
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
