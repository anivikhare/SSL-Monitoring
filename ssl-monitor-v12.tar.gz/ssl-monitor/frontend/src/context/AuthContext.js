import React, { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("ssl_token");
    const username = localStorage.getItem("ssl_user");
    const role = localStorage.getItem("ssl_role");
    if (token && username) setUser({ token, username, role });
    setLoading(false);
  }, []);

  const login = (token, username, role) => {
    localStorage.setItem("ssl_token", token);
    localStorage.setItem("ssl_user", username);
    localStorage.setItem("ssl_role", role);
    setUser({ token, username, role });
  };

  const logout = () => {
    localStorage.removeItem("ssl_token");
    localStorage.removeItem("ssl_user");
    localStorage.removeItem("ssl_role");
    setUser(null);
  };

  const isAdmin = () => user?.role === "admin";
  const isReadonly = () => user?.role === "readonly";

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, isAdmin, isReadonly }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
