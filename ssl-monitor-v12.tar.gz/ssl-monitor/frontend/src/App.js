import React, { useState } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";
import Users from "./pages/Users";
import Settings from "./pages/Settings";
import Trash from "./pages/Trash";
import ActivityLog from "./pages/ActivityLog";
import Reminders from "./pages/Reminders";
import Navbar from "./components/Navbar";
import "./App.css";

function AppContent() {
  const { user, loading, isAdmin, isReadonly } = useAuth();
  const [activePage, setActivePage] = useState("dashboard");

  if (loading) return <div className="page-loading">Loading...</div>;
  if (!user) return <Login />;

  // readonly can only see dashboard
  // non-admin cannot see users/settings
  const page =
    (isReadonly() && activePage !== "dashboard") ? "dashboard" :
    (["users","settings"].includes(activePage) && !isAdmin()) ? "dashboard" :
    activePage;

  return (
    <div className="app">
      <Navbar activePage={page} setActivePage={setActivePage} />
      <main className="main-content">
        {page === "dashboard" && <Dashboard />}
        {page === "projects" && !isReadonly() && <Projects />}
        {page === "users" && isAdmin() && <Users />}
        {page === "settings" && isAdmin() && <Settings />}
        {page === "trash" && isAdmin() && <Trash />}
        {page === "activity" && isAdmin() && <ActivityLog />}
        {page === "reminders" && <Reminders />}
      </main>
    </div>
  );
}

export default function App() {
  return <AuthProvider><AppContent /></AuthProvider>;
}
