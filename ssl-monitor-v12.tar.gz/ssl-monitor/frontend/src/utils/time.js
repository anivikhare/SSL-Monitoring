export function toIST(dateStr) {
  if (!dateStr) return "—";
  // Timestamps are now stored as IST directly — parse as IST
  const date = new Date(dateStr.replace(" ", "T") + "+05:30");
  return date.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" });
}

export function timeAgo(dateStr) {
  if (!dateStr) return "—";
  // Timestamps stored as IST — parse as IST
  const date = new Date(dateStr.replace(" ", "T") + "+05:30");
  const diff = Date.now() - date.getTime();
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (diff < 0)   return "just now";
  if (mins < 1)   return "just now";
  if (mins < 60)  return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}
