import React, { useEffect, useState } from "react";
import { activityAPI } from "../api";
import { toIST, timeAgo } from "../utils/time";

const ACTION_LABELS = {
  LOGIN:       { label: "Logged in",      color: "#2563eb", bg: "#eff6ff" },
  CREATE:      { label: "Created",        color: "#16a34a", bg: "#dcfce7" },
  UPDATE:      { label: "Updated",        color: "#d97706", bg: "#fef3c7" },
  DELETE:      { label: "Deleted",        color: "#dc2626", bg: "#fee2e2" },
  ADD_FQDN:    { label: "Added FQDN",     color: "#16a34a", bg: "#dcfce7" },
  DELETE_FQDN: { label: "Deleted FQDN",   color: "#dc2626", bg: "#fee2e2" },
};


export default function ActivityLog() {
  const [logs, setLogs] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState({ user: "", action: "" });
  const [clearing, setClearing] = useState(false);
  const limit = 50;

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const res = await activityAPI.getAll({
        page, limit,
        user: filter.user || undefined,
        action: filter.action || undefined,
      });
      setLogs(res.data.logs);
      setTotal(res.data.total);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchLogs(); }, [page, filter]);

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(fetchLogs, 30000);
    return () => clearInterval(interval);
  }, [page, filter]);

  const handleClear = async () => {
    if (!window.confirm("Clear all activity logs? This cannot be undone.")) return;
    setClearing(true);
    await activityAPI.clear();
    setClearing(false);
    fetchLogs();
  };

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Activity Log</h1>
          <p className="page-subtitle">{total} total events</p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="btn btn-outline" onClick={fetchLogs} disabled={loading}>
            {loading ? "Loading..." : "↻ Refresh"}
          </button>
          <button className="btn btn-danger" onClick={handleClear} disabled={clearing}>
            {clearing ? "Clearing..." : "Clear Log"}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
        <input type="text" placeholder="Filter by user..."
          value={filter.user}
          onChange={e => { setFilter(f => ({ ...f, user: e.target.value })); setPage(1); }}
          style={{ padding: "7px 12px", border: "1px solid var(--border)", borderRadius: 6, fontSize: 13, minWidth: 180 }} />
        <select value={filter.action}
          onChange={e => { setFilter(f => ({ ...f, action: e.target.value })); setPage(1); }}
          style={{ padding: "7px 12px", border: "1px solid var(--border)", borderRadius: 6, fontSize: 13, background: "white" }}>
          <option value="">All actions</option>
          <option value="LOGIN">Login</option>
          <option value="CREATE">Create</option>
          <option value="UPDATE">Update</option>
          <option value="DELETE">Delete</option>
          <option value="ADD_FQDN">Add FQDN</option>
          <option value="DELETE_FQDN">Delete FQDN</option>
        </select>
      </div>

      {/* Log table */}
      <div className="users-table-wrap">
        <table className="fqdn-table" style={{ width: "100%" }}>
          <thead>
            <tr>
              <th>Time</th>
              <th>User</th>
              <th>Action</th>
              <th>Target</th>
              <th>Details</th>
              <th>IP</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} style={{ padding: 24, textAlign: "center", color: "var(--text-muted)" }}>Loading...</td></tr>
            ) : logs.length === 0 ? (
              <tr><td colSpan={6} style={{ padding: 24, textAlign: "center", color: "var(--text-muted)" }}>No activity recorded yet</td></tr>
            ) : logs.map(log => {
              const act = ACTION_LABELS[log.action] || { label: log.action, color: "#64748b", bg: "#f1f5f9" };
              return (
                <tr key={log.id}>
                  <td style={{ whiteSpace: "nowrap" }}>
                    <div style={{ fontSize: 13 }}>{timeAgo(log.created_at)}</div>
                    <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{toIST(log.created_at)}</div>
                  </td>
                  <td style={{ fontWeight: 600, fontSize: 13 }}>{log.username}</td>
                  <td>
                    <span style={{ background: act.bg, color: act.color, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 100 }}>
                      {act.label}
                    </span>
                  </td>
                  <td style={{ fontSize: 13 }}>
                    {log.entity_type && <span style={{ color: "var(--text-muted)", fontSize: 11, marginRight: 4 }}>{log.entity_type}</span>}
                    <span style={{ fontFamily: "monospace", fontSize: 12 }}>{log.entity_name || "—"}</span>
                  </td>
                  <td style={{ fontSize: 12, color: "var(--text-muted)" }}>{log.details || "—"}</td>
                  <td style={{ fontSize: 12, color: "var(--text-muted)", fontFamily: "monospace" }}>{log.ip || "—"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 16, justifyContent: "center" }}>
          <button className="btn btn-outline btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
          <span style={{ fontSize: 13, color: "var(--text-muted)" }}>Page {page} of {totalPages}</span>
          <button className="btn btn-outline btn-sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Next →</button>
        </div>
      )}
    </div>
  );
}
