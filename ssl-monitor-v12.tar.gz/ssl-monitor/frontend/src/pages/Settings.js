import React, { useEffect, useState } from "react";
import { settingsAPI } from "../api";
import EmailChipInput from "../components/EmailChipInput";

const TABS = [
  { id: "smtp",     label: "📧 SMTP",     title: "SMTP Configuration" },
  { id: "alerts",   label: "🔔 Alerts",   title: "Alert Configuration" },
  { id: "schedule", label: "⏰ Schedule", title: "Schedule Configuration" },
  { id: "ldap",     label: "🏢 LDAP",     title: "Active Directory" },
  { id: "proxy",    label: "🔀 Proxy",    title: "Proxy Configuration" },
];

export default function Settings() {
  const [activeTab, setActiveTab] = useState("smtp");
  const [form, setForm] = useState({
    smtp_host: "", smtp_port: "25", smtp_secure: "false",
    smtp_user: "", smtp_pass: "", smtp_from: "ssl-monitor@example.com",
    alerts_enabled: "false", alert_thresholds: "30,14,7", daily_alert_days: "7",
    global_cc: "",
    cron_ssl_check: "0 */6 * * *", cron_alert: "0 8 * * *",
    proxy_host: "", proxy_port: "8080",
    ldap_enabled: "false", ldap_url: "", ldap_domain: "",
    ldap_base_dn: "", ldap_bind_dn: "", ldap_bind_pass: "",
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [thresholdInput, setThresholdInput] = useState("");
  const [thresholdError, setThresholdError] = useState("");
  const [testingEmail, setTestingEmail] = useState(false);
  const [testingLdap, setTestingLdap] = useState(false);
  const [runningAlert, setRunningAlert] = useState(false);
  const [cronStatus, setCronStatus] = useState(null);
  const [cronAdvancedSSL, setCronAdvancedSSL] = useState(false);
  const [cronAdvancedAlert, setCronAdvancedAlert] = useState(false);
  const [testEmailTo, setTestEmailTo] = useState("");
  const [msg, setMsg] = useState({ type: "", text: "" });

  useEffect(() => {
    settingsAPI.get().then((res) => {
      setForm((f) => ({ ...f, ...res.data }));
      setLoading(false);
    });
    settingsAPI.cronStatus().then(res => setCronStatus(res.data)).catch(() => {});
  }, []);

  const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true); setMsg({ type: "", text: "" });
    try {
      await settingsAPI.update(form);
      setMsg({ type: "success", text: "Settings saved." });
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.error || "Failed to save" });
    } finally {
      setSaving(false);
    }
  };

  const handleTestEmail = async () => {
    if (!testEmailTo) { setMsg({ type: "error", text: "Enter a recipient email" }); return; }
    setTestingEmail(true); setMsg({ type: "", text: "" });
    try {
      await settingsAPI.testEmail(testEmailTo);
      setMsg({ type: "success", text: `Test email sent to ${testEmailTo}` });
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.error || "Failed to send" });
    } finally { setTestingEmail(false); }
  };

  const handleRunAlert = async () => {
    setRunningAlert(true); setMsg({ type: "", text: "" });
    try {
      const res = await settingsAPI.runAlertNow();
      setMsg({ type: "success", text: `Alert triggered — checked ${res.data.checked || 0} certs, sent ${res.data.emails_sent || 0} email(s)` });
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.error || "Failed" });
    } finally { setRunningAlert(false); }
  };

  const handleTestLdap = async () => {
    setTestingLdap(true); setMsg({ type: "", text: "" });
    try {
      const res = await settingsAPI.testLdap();
      setMsg({ type: "success", text: res.data.message || "LDAP connection successful" });
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.error || "LDAP test failed" });
    } finally { setTestingLdap(false); }
  };

  const addThreshold = () => {
    const val = thresholdInput.trim();
    if (!val || isNaN(val) || parseInt(val) < 1) { setThresholdError("Enter a valid number of days"); return; }
    const existing = form.alert_thresholds.split(",").map(d => d.trim()).filter(Boolean);
    if (existing.includes(val)) { setThresholdError("Already in the list"); return; }
    set("alert_thresholds", [...existing, val].join(","));
    setThresholdInput(""); setThresholdError("");
  };

  if (loading) return <div className="page-loading">Loading settings...</div>;

  const currentTab = TABS.find(t => t.id === activeTab);

  return (
    <div className="page">
      <div className="page-header">
        <h1>Settings</h1>
      </div>

      {msg.text && (
        <div className={`alert ${msg.type === "success" ? "alert-success" : "alert-error"}`}>
          {msg.text}
        </div>
      )}

      {/* Tab Bar */}
      <div className="settings-tabs">
        {TABS.map(tab => (
          <button key={tab.id}
            className={`settings-tab ${activeTab === tab.id ? "active" : ""}`}
            onClick={() => { setActiveTab(tab.id); setMsg({ type: "", text: "" }); }}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="settings-tab-content">
        <form onSubmit={handleSave}>

          {/* ── SMTP ─────────────────────────────────────────── */}
          {activeTab === "smtp" && (
            <>
              <div className="settings-section-title">{currentTab.title}</div>
              <div className="form-row-3">
                <div className="form-group">
                  <label>SMTP Host (FQDN)</label>
                  <input type="text" value={form.smtp_host}
                    onChange={e => set("smtp_host", e.target.value)} placeholder="smtp.example.com" />
                </div>
                <div className="form-group">
                  <label>Port</label>
                  <input type="number" value={form.smtp_port}
                    onChange={e => set("smtp_port", e.target.value)} placeholder="25" />
                </div>
                <div className="form-group">
                  <label>Encryption</label>
                  <select className="form-select" value={form.smtp_secure}
                    onChange={e => set("smtp_secure", e.target.value)}>
                    <option value="false">None / STARTTLS (25/587)</option>
                    <option value="true">SSL/TLS (465)</option>
                  </select>
                </div>
              </div>
              <div className="form-row-3">
                <div className="form-group">
                  <label>Username <span className="label-hint">(optional)</span></label>
                  <input type="text" value={form.smtp_user}
                    onChange={e => set("smtp_user", e.target.value)} placeholder="optional" />
                </div>
                <div className="form-group">
                  <label>Password <span className="label-hint">(optional)</span></label>
                  <input type="password" value={form.smtp_pass}
                    onChange={e => set("smtp_pass", e.target.value)} placeholder="optional" />
                </div>
                <div className="form-group">
                  <label>From Address</label>
                  <input type="email" value={form.smtp_from}
                    onChange={e => set("smtp_from", e.target.value)} placeholder="ssl-monitor@example.com" />
                </div>
              </div>

              <div className="settings-divider" />
              <div className="settings-section-title" style={{ fontSize: 13 }}>Send Test Email</div>
              <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
                <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
                  <label>Recipient</label>
                  <input type="email" value={testEmailTo}
                    onChange={e => setTestEmailTo(e.target.value)} placeholder="recipient@example.com" />
                </div>
                <button type="button" className="btn btn-outline"
                  onClick={handleTestEmail} disabled={testingEmail || !form.smtp_host}>
                  {testingEmail ? "Sending..." : "✉️ Send Test"}
                </button>
              </div>
              {!form.smtp_host && <p className="setting-hint" style={{ color: "var(--warn)", marginTop: 6 }}>Configure SMTP host first.</p>}
            </>
          )}

          {/* ── ALERTS ───────────────────────────────────────── */}
          {activeTab === "alerts" && (
            <>
              <div className="settings-section-title">{currentTab.title}</div>

              <div className="form-group">
                <label className="checkbox-label" style={{ border: "none", padding: 0 }}>
                  <input type="checkbox"
                    checked={form.alerts_enabled === "true"}
                    onChange={e => set("alerts_enabled", e.target.checked ? "true" : "false")} />
                  Enable email alerts
                </label>
                <p className="setting-hint">Alert recipients are set per-project and per-group in the Projects page.</p>
              </div>

              <div className="form-group">
                <EmailChipInput
                  label="Global CC"
                  hint="added as CC to every alert email"
                  value={form.global_cc}
                  onChange={val => set("global_cc", val)}
                  placeholder="director@example.com"
                />
              </div>

              <div className="settings-divider" />
              <div className="settings-section-title" style={{ fontSize: 13 }}>TLS Certificate Expiry — Alert Thresholds</div>
              <p className="setting-hint" style={{ marginBottom: 12 }}>Send alert when certificate expires in:</p>

              <div className="threshold-list">
                {(form.alert_thresholds || "")
                  .split(",").map(d => d.trim()).filter(Boolean)
                  .sort((a, b) => parseInt(b) - parseInt(a))
                  .map(day => (
                    <div key={day} className="threshold-item">
                      <span className="threshold-day">{day} days</span>
                      <button type="button" className="threshold-remove"
                        onClick={() => {
                          const updated = form.alert_thresholds
                            .split(",").map(d => d.trim()).filter(d => d !== day).join(",");
                          set("alert_thresholds", updated);
                        }}>×</button>
                    </div>
                  ))
                }
              </div>
              <div className="threshold-add-row">
                <input type="number" min="1" max="365"
                  value={thresholdInput}
                  onChange={e => { setThresholdInput(e.target.value); setThresholdError(""); }}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addThreshold(); } }}
                  placeholder="day" className="threshold-input" />
                <button type="button" className="threshold-add-btn" onClick={addThreshold}>+</button>
              </div>
              {thresholdError && <div className="email-chip-error">{thresholdError}</div>}

              <div className="settings-divider" />
              <div className="form-group" style={{ maxWidth: 340 }}>
                <label>Daily repeat alert below <span className="label-hint">(days)</span></label>
                <select className="form-select" value={form.daily_alert_days}
                  onChange={e => set("daily_alert_days", e.target.value)}>
                  <option value="3">3 days</option>
                  <option value="5">5 days</option>
                  <option value="7">7 days (default)</option>
                  <option value="10">10 days</option>
                  <option value="14">14 days</option>
                  <option value="21">21 days</option>
                  <option value="30">30 days</option>
                </select>
                <p className="setting-hint">Sends alert every day when days left is below this, until cert is renewed</p>
              </div>

              <div className="settings-divider" />
              <div className="settings-section-title" style={{ fontSize: 13 }}>Manual Trigger</div>
              <p className="setting-hint" style={{ marginBottom: 8 }}>Send expiry alert emails immediately without waiting for schedule.</p>
              <button type="button" className="btn btn-outline"
                onClick={handleRunAlert} disabled={runningAlert}>
                {runningAlert ? "Sending..." : "🔔 Run Alert Now"}
              </button>
            </>
          )}

          {/* ── SCHEDULE ─────────────────────────────────────── */}
          {activeTab === "schedule" && (
            <>
              <div className="settings-section-title">{currentTab.title}</div>
              {cronStatus && (
                <p className="setting-hint" style={{ marginBottom: 16 }}>
                  🕐 Server time: {cronStatus.server_time_ist}
                </p>
              )}

              <div className="cron-row" style={{ padding: "16px 0" }}>
                <div className="cron-row-icon">🔍</div>
                <div className="cron-row-body">
                  <div className="cron-row-title">SSL Certificate Check</div>
                  <div className="cron-row-desc">How often to scan all certificates</div>
                </div>
                <div className="cron-row-control">
                  {!cronAdvancedSSL ? (
                    <select className="cron-select" value={form.cron_ssl_check}
                      onChange={e => set("cron_ssl_check", e.target.value)}>
                      <option value="0 */1 * * *">Every 1 hour</option>
                      <option value="0 */2 * * *">Every 2 hours</option>
                      <option value="0 */4 * * *">Every 4 hours</option>
                      <option value="0 */6 * * *">Every 6 hours</option>
                      <option value="0 */8 * * *">Every 8 hours</option>
                      <option value="0 */12 * * *">Every 12 hours</option>
                      <option value="0 0 * * *">Once daily (midnight)</option>
                    </select>
                  ) : (
                    <input className="cron-expr-input" type="text" value={form.cron_ssl_check}
                      onChange={e => set("cron_ssl_check", e.target.value)} placeholder="0 */6 * * *" />
                  )}
                  <button type="button" className="cron-toggle-btn"
                    onClick={() => setCronAdvancedSSL(!cronAdvancedSSL)}>
                    {cronAdvancedSSL ? "Simple" : "Advanced"}
                  </button>
                </div>
                {cronStatus && (
                  <div className="cron-row-status">
                    <code>{cronStatus.ssl_check?.expr}</code>
                    <span className={cronStatus.ssl_check?.valid ? "cron-valid" : "cron-invalid"}>
                      {cronStatus.ssl_check?.valid ? "✓" : "✗"}
                    </span>
                  </div>
                )}
              </div>

              <div className="cron-row-divider" />

              <div className="cron-row" style={{ padding: "16px 0" }}>
                <div className="cron-row-icon">🔔</div>
                <div className="cron-row-body">
                  <div className="cron-row-title">Daily Alert Email</div>
                  <div className="cron-row-desc">When to send expiry alert emails (IST)</div>
                </div>
                <div className="cron-row-control">
                  {!cronAdvancedAlert ? (
                    <select className="cron-select" value={form.cron_alert}
                      onChange={e => set("cron_alert", e.target.value)}>
                      <option value="0 6 * * *">6:00 AM IST</option>
                      <option value="0 7 * * *">7:00 AM IST</option>
                      <option value="0 8 * * *">8:00 AM IST</option>
                      <option value="0 9 * * *">9:00 AM IST</option>
                      <option value="0 10 * * *">10:00 AM IST</option>
                      <option value="0 11 * * *">11:00 AM IST</option>
                      <option value="0 12 * * *">12:00 PM IST</option>
                      <option value="0 13 * * *">1:00 PM IST</option>
                      <option value="0 14 * * *">2:00 PM IST</option>
                      <option value="0 18 * * *">6:00 PM IST</option>
                    </select>
                  ) : (
                    <input className="cron-expr-input" type="text" value={form.cron_alert}
                      onChange={e => set("cron_alert", e.target.value)} placeholder="0 8 * * *" />
                  )}
                  <button type="button" className="cron-toggle-btn"
                    onClick={() => setCronAdvancedAlert(!cronAdvancedAlert)}>
                    {cronAdvancedAlert ? "Simple" : "Advanced"}
                  </button>
                </div>
                {cronStatus && (
                  <div className="cron-row-status">
                    <code>{cronStatus.alert?.expr}</code>
                    <span className={cronStatus.alert?.valid ? "cron-valid" : "cron-invalid"}>
                      {cronStatus.alert?.valid ? "✓" : "✗"}
                    </span>
                  </div>
                )}
              </div>
            </>
          )}

          {/* ── LDAP ─────────────────────────────────────────── */}
          {activeTab === "ldap" && (
            <>
              <div className="settings-section-title">{currentTab.title}</div>
              <div className="form-group">
                <label className="checkbox-label" style={{ border: "none", padding: 0 }}>
                  <input type="checkbox"
                    checked={form.ldap_enabled === "true"}
                    onChange={e => set("ldap_enabled", e.target.checked ? "true" : "false")} />
                  Enable Active Directory login for non-admin users
                </label>
                <p className="setting-hint">Admin always uses local password regardless.</p>
              </div>
              <div className="form-row-2">
                <div className="form-group">
                  <label>LDAP URL</label>
                  <input type="text" value={form.ldap_url}
                    onChange={e => set("ldap_url", e.target.value)}
                    placeholder="ldap://dc.example.com" />
                </div>
                <div className="form-group">
                  <label>Domain <span className="label-hint">(appended to username)</span></label>
                  <input type="text" value={form.ldap_domain}
                    onChange={e => set("ldap_domain", e.target.value)} placeholder="example.com" />
                </div>
              </div>
              <div className="form-row-2">
                <div className="form-group">
                  <label>Base DN <span className="label-hint">(optional)</span></label>
                  <input type="text" value={form.ldap_base_dn}
                    onChange={e => set("ldap_base_dn", e.target.value)} placeholder="DC=ril,DC=com" />
                </div>
                <div className="form-group">
                  <label>Bind DN <span className="label-hint">(optional)</span></label>
                  <input type="text" value={form.ldap_bind_dn}
                    onChange={e => set("ldap_bind_dn", e.target.value)}
                    placeholder="CN=svc,CN=Users,DC=ril,DC=com" />
                </div>
              </div>
              <div className="form-group" style={{ maxWidth: 340 }}>
                <label>Bind Password <span className="label-hint">(optional)</span></label>
                <input type="password" value={form.ldap_bind_pass}
                  onChange={e => set("ldap_bind_pass", e.target.value)} placeholder="optional" />
              </div>
              <div className="settings-hint-box">
                Users bind as <code>{`{username}@${form.ldap_domain || "example.com"}`}</code> — no password stored in SSL Monitor.
              </div>

              <div className="settings-divider" />
              <button type="button" className="btn btn-outline"
                onClick={handleTestLdap} disabled={testingLdap || !form.ldap_url}>
                {testingLdap ? "Testing..." : "🔗 Test LDAP Connection"}
              </button>
              {!form.ldap_url && <p className="setting-hint" style={{ color: "var(--warn)", marginTop: 6 }}>Configure LDAP URL first.</p>}
            </>
          )}

          {/* ── PROXY ────────────────────────────────────────── */}
          {activeTab === "proxy" && (
            <>
              <div className="settings-section-title">{currentTab.title}</div>
              <p className="setting-hint" style={{ marginBottom: 16 }}>
                Configure HTTP proxy for FQDNs only accessible via proxy. Enable per-domain in the Projects page.
              </p>
              <div className="form-row-2">
                <div className="form-group">
                  <label>Proxy Host (FQDN)</label>
                  <input type="text" value={form.proxy_host}
                    onChange={e => set("proxy_host", e.target.value)}
                    placeholder="proxy.example.com" />
                </div>
                <div className="form-group">
                  <label>Proxy Port</label>
                  <input type="number" value={form.proxy_port}
                    onChange={e => set("proxy_port", e.target.value)} placeholder="8080" />
                </div>
              </div>
              {form.proxy_host && (
                <div className="settings-hint-box">
                  Proxy-enabled FQDNs will use: <code>{form.proxy_host}:{form.proxy_port}</code>
                </div>
              )}
            </>
          )}

          <div style={{ marginTop: 24 }}>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? "Saving..." : "Save Settings"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
