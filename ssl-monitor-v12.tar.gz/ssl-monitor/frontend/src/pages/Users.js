import React, { useEffect, useState } from "react";
import { authAPI, projectAPI } from "../api";
import { toIST } from "../utils/time";

export default function Users() {
  const [users, setUsers] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [editUser, setEditUser] = useState(null);
  const [error, setError] = useState("");

  const fetchAll = async () => {
    try {
      const [uRes, pRes] = await Promise.all([authAPI.getUsers(), projectAPI.getAll()]);
      setUsers(uRes.data);
      setProjects(pRes.data);
    } catch { setError("Failed to load data"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleDelete = async (id, username) => {
    if (!window.confirm(`Delete user "${username}"?`)) return;
    try { await authAPI.deleteUser(id); fetchAll(); }
    catch (err) { setError(err.response?.data?.error || "Delete failed"); }
  };

  if (loading) return <div className="page-loading">Loading users...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>User Management</h1>
        <button className="btn btn-primary" onClick={() => { setShowCreate(true); setEditUser(null); }}>
          + Create User
        </button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="info-banner" style={{ marginBottom: 20 }}>
        <strong>Local users</strong> log in with their username/password.
        &nbsp;<strong>LDAP users</strong> log in with their Windows domain password — no password stored here.
        Admin always uses local login.
      </div>

      {(showCreate || editUser) && (
        <UserForm
          user={editUser} projects={projects}
          onClose={() => { setShowCreate(false); setEditUser(null); }}
          onSaved={() => { setShowCreate(false); setEditUser(null); fetchAll(); }}
        />
      )}

      <div className="users-table-wrap">
        <table className="fqdn-table">
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th>Auth</th>
              <th>AD Username</th>
              <th>Last Login</th>
              <th>Role</th>
              <th>Assigned Projects</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td><strong>{u.username}</strong></td>
                <td className="fqdn-cell">{u.email || <span className="text-muted">—</span>}</td>
                <td>
                  <span className={`auth-badge ${u.auth_type === "ldap" ? "auth-ldap" : "auth-local"}`}>
                    {u.auth_type === "ldap" ? "AD/LDAP" : "Local"}
                  </span>
                </td>
                <td className="fqdn-cell">
                  {u.ad_username || <span className="text-muted">—</span>}
                </td>
                <td style={{ fontSize: 12, color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                  {u.last_login
                    ? toIST(u.last_login)
                    : <span>Never</span>}
                </td>
                <td>
                  <span className={`role-badge ${u.role === "admin" ? "role-admin" : u.role === "readonly" ? "role-readonly" : "role-user"}`}>
                    {u.role}
                  </span>
                </td>
                <td>
                  {u.role === "admin" ? (
                    <span className="text-muted">All projects</span>
                  ) : u.project_ids.length === 0 ? (
                    <span className="text-muted">None</span>
                  ) : (
                    <div className="project-tags">
                      {u.project_ids.map((pid) => {
                        const p = projects.find((x) => x.id === pid);
                        return p ? <span key={pid} className="project-tag">{p.name}</span> : null;
                      })}
                    </div>
                  )}
                </td>
                <td>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button className="btn btn-sm btn-outline"
                      onClick={() => { setEditUser(u); setShowCreate(false); }}>Edit</button>
                    <button className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(u.id, u.username)}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function UserForm({ user, projects, onClose, onSaved }) {
  const isEdit = !!user;
  const [form, setForm] = useState({
    username: user?.username || "",
    email: user?.email || "",
    password: "",
    role: user?.role || "user",
    auth_type: user?.auth_type || "local",
    ad_username: user?.ad_username || "",
    project_ids: user?.project_ids || [],
  });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const toggleProject = (pid) =>
    setForm((f) => ({
      ...f,
      project_ids: f.project_ids.includes(pid)
        ? f.project_ids.filter((x) => x !== pid)
        : [...f.project_ids, pid],
    }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (!isEdit && form.auth_type === "local" && !form.password) {
      setError("Password is required for local users"); return;
    }
    if (form.auth_type === "ldap" && !form.ad_username) {
      setError("AD username is required for LDAP users"); return;
    }
    setSaving(true);
    try {
      if (isEdit) {
        const payload = {
          project_ids: form.project_ids, email: form.email,
          role: form.role, auth_type: form.auth_type,
          ad_username: form.ad_username,
        };
        if (form.password) payload.password = form.password;
        await authAPI.updateUser(user.id, payload);
      } else {
        await authAPI.createUser(form);
      }
      onSaved();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="user-form-card">
      <div className="user-form-header">
        <h3>{isEdit ? `Edit: ${user.username}` : "Create New User"}</h3>
        <button className="modal-close" onClick={onClose}>×</button>
      </div>
      <form onSubmit={handleSubmit}>
        {error && <div className="alert alert-error">{error}</div>}

        <div className="form-row">
          <div className="form-group">
            <label>Username</label>
            <input type="text" value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
              disabled={isEdit} required={!isEdit} placeholder="johndoe" />
          </div>
          <div className="form-group">
            <label>Email</label>
            <input type="email" value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="john.doe@example.com" />
          </div>
          <div className="form-group">
            <label>Role</label>
            <select className="form-select" value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}>
              <option value="user">User (can add FQDNs)</option>
              <option value="readonly">Read-only (dashboard only)</option>
              <option value="admin">Admin (full access)</option>
            </select>
          </div>
        </div>

        {/* Auth type selector */}
        <div className="form-group">
          <label>Authentication Type</label>
          <div className="auth-type-selector">
            <label className={`auth-type-option ${form.auth_type === "local" ? "selected" : ""}`}>
              <input type="radio" name="auth_type" value="local"
                checked={form.auth_type === "local"}
                onChange={() => setForm({ ...form, auth_type: "local" })} />
              <div>
                <strong>Local Password</strong>
                <p>User logs in with a password stored in SSL Monitor</p>
              </div>
            </label>
            <label className={`auth-type-option ${form.auth_type === "ldap" ? "selected" : ""}`}>
              <input type="radio" name="auth_type" value="ldap"
                checked={form.auth_type === "ldap"}
                onChange={() => setForm({ ...form, auth_type: "ldap" })} />
              <div>
                <strong>Active Directory (LDAP)</strong>
                <p>User logs in with their Windows domain password — no password stored here</p>
              </div>
            </label>
          </div>
        </div>

        {/* Show fields based on auth type */}
        {form.auth_type === "local" ? (
          <div className="form-group" style={{ maxWidth: 340 }}>
            <label>{isEdit ? "New Password (blank = keep)" : "Password"}</label>
            <input type="password" value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder={isEdit ? "Leave blank to keep" : "••••••••"} />
          </div>
        ) : (
          <div className="form-group" style={{ maxWidth: 400 }}>
            <label>AD Username <span className="label-hint">(without @domain, e.g. john.doe)</span></label>
            <input type="text" value={form.ad_username}
              onChange={(e) => setForm({ ...form, ad_username: e.target.value })}
              placeholder="john.doe" required={form.auth_type === "ldap"} />
            <p className="setting-hint">
              This user will log in using their Windows domain password.
              Make sure LDAP is enabled and configured in Settings.
            </p>
          </div>
        )}

        {/* Project assignment for non-admin */}
        {form.role !== "admin" && (
          <div className="form-group">
            <label>
              Assign to Projects
              <span className="label-hint"> — user can access these projects</span>
            </label>
            {projects.length === 0 ? (
              <p className="text-muted">No projects yet.</p>
            ) : (
              <div className="project-checkboxes">
                {projects.map((p) => (
                  <label key={p.id} className="checkbox-label">
                    <input type="checkbox"
                      checked={form.project_ids.includes(p.id)}
                      onChange={() => toggleProject(p.id)} />
                    {p.name}
                  </label>
                ))}
              </div>
            )}
          </div>
        )}

        <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Saving..." : isEdit ? "Save Changes" : "Create User"}
          </button>
          <button type="button" className="btn btn-outline" onClick={onClose}>Cancel</button>
        </div>
      </form>
    </div>
  );
}
