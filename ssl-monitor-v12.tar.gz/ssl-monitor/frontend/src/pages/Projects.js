import React, { useEffect, useState } from "react";
import { projectAPI, groupAPI, fqdnAPI } from "../api";
import { useAuth } from "../context/AuthContext";
import StatusBadge from "../components/StatusBadge";
import EmailChipInput from "../components/EmailChipInput";
import BulkImportModal from "../components/BulkImportModal";

export default function Projects() {
  const { isAdmin } = useAuth();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newProject, setNewProject] = useState("");
  const [showNewProject, setShowNewProject] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [activeProjectId, setActiveProjectId] = useState(null);

  const fetchProjects = async () => {
    try {
      const res = await projectAPI.getAll();
      setProjects(res.data);
      setActiveProjectId(prev => {
        if (prev && res.data.some(p => p.id === prev)) return prev;
        return res.data.length ? res.data[0].id : null;
      });
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchProjects(); }, []);

  const handleAddProject = async (e) => {
    e.preventDefault();
    if (!newProject.trim()) return;
    await projectAPI.create({ name: newProject.trim() });
    setNewProject(""); setShowNewProject(false);
    fetchProjects();
  };

  const handleUpdateProject = async (e) => {
    e.preventDefault();
    if (!editingProject.name.trim()) return;
    try {
      await projectAPI.update(editingProject.id, {
        name: editingProject.name.trim(),
        alert_emails: editingProject.alert_emails || "",
        cc_emails: editingProject.cc_emails || "",
      });
      setEditingProject(null);
      // Optimistically update name in UI immediately
      setProjects(prev => prev.map(p =>
        p.id === editingProject.id
          ? { ...p, name: editingProject.name.trim(), alert_emails: editingProject.alert_emails, cc_emails: editingProject.cc_emails }
          : p
      ));
      // Then fetch fresh data from server
      await fetchProjects();
    } catch (err) {
      console.error("Update failed", err);
      fetchProjects();
    }
  };

  const handleDeleteProject = async (id) => {
    if (!window.confirm("Delete this project and all its data?")) return;
    try {
      await projectAPI.delete(id);
      // Optimistically remove from UI immediately
      setProjects(prev => prev.filter(p => p.id !== id));
      // Then fetch fresh data from server
      await fetchProjects();
    } catch (err) {
      console.error("Delete failed", err);
      fetchProjects();
    }
  };

  if (loading) return <div className="page-loading">Loading projects...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Projects</h1>
        {isAdmin() && (
          <button className="btn btn-primary" onClick={() => setShowNewProject(!showNewProject)}>
            + New Project
          </button>
        )}
      </div>

      {!isAdmin() && (
        <div className="info-banner">
          You can add FQDNs to your assigned projects. Contact an admin for project/group changes.
        </div>
      )}

      {showNewProject && isAdmin() && (
        <form className="inline-form" onSubmit={handleAddProject}>
          <input type="text" placeholder="Project name" value={newProject}
            onChange={(e) => setNewProject(e.target.value)} autoFocus />
          <button type="submit" className="btn btn-primary">Create</button>
          <button type="button" className="btn btn-outline" onClick={() => setShowNewProject(false)}>Cancel</button>
        </form>
      )}

      {/* Project Edit Modal */}
      {editingProject && (
        <div className="modal-overlay" onClick={() => setEditingProject(null)}>
          <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Edit Project — {editingProject.originalName}</h3>
              <button className="modal-close" onClick={() => setEditingProject(null)}>×</button>
            </div>
            <form onSubmit={handleUpdateProject}>
              <div className="form-group">
                <label>Project Name</label>
                <input type="text" value={editingProject.name}
                  onChange={e => setEditingProject({ ...editingProject, name: e.target.value })}
                  required />
              </div>
              <EmailChipInput
                label="Alert Recipients (TO)"
                hint="main recipients for all groups in this project"
                value={editingProject.alert_emails}
                onChange={val => setEditingProject({ ...editingProject, alert_emails: val })}
                placeholder="user@example.com"
              />
              <EmailChipInput
                label="CC Recipients"
                hint="copied on all alerts for this project"
                value={editingProject.cc_emails}
                onChange={val => setEditingProject({ ...editingProject, cc_emails: val })}
                placeholder="manager@example.com"
              />
              <div className="info-banner" style={{ margin: "12px 0" }}>
                Group-level recipients override project recipients for that group's FQDNs.
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                <button type="submit" className="btn btn-primary">Save Changes</button>
                <button type="button" className="btn btn-outline" onClick={() => setEditingProject(null)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Project Tabs */}
      {projects.length > 0 && (
        <div className="settings-tabs project-tabs-bar">
          {projects.map((project) => (
            <button key={project.id}
              className={`settings-tab ${activeProjectId === project.id ? "active" : ""}`}
              onClick={() => setActiveProjectId(project.id)}>
              {project.name}
            </button>
          ))}
        </div>
      )}

      {projects.filter(p => p.id === activeProjectId).map((project) => (
        <div key={project.id} className="project-card">
          <div className="project-card-header">
            <div>
              <h2 style={{ marginBottom: 2 }}>{project.name}</h2>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 4 }}>
                {project.alert_emails && (
                  <span className="email-summary-tag email-to">
                    TO: {project.alert_emails.split(",").length} recipient{project.alert_emails.split(",").length > 1 ? "s" : ""}
                  </span>
                )}
                {project.cc_emails && (
                  <span className="email-summary-tag email-cc">
                    CC: {project.cc_emails.split(",").length} recipient{project.cc_emails.split(",").length > 1 ? "s" : ""}
                  </span>
                )}
              </div>
            </div>
            {isAdmin() && (
              <div className="card-actions">
                <button className="btn btn-sm btn-outline"
                  onClick={() => setEditingProject({
                    id: project.id,
                    name: project.name,
                    originalName: project.name,
                    alert_emails: project.alert_emails || "",
                    cc_emails: project.cc_emails || "",
                  })}>
                  ✏️ Edit
                </button>
                <AddGroupButton projectId={project.id} onRefresh={fetchProjects} />
                <button className="btn btn-sm btn-danger" onClick={() => handleDeleteProject(project.id)}>
                  Delete
                </button>
              </div>
            )}
          </div>

          {project.groups?.map((group) => (
            <GroupSection key={group.id} group={group} isAdmin={isAdmin()} onRefresh={fetchProjects} />
          ))}
        </div>
      ))}

      {projects.length === 0 && (
        <div className="empty-state">
          {isAdmin() ? "No projects yet. Create one to get started." : "No projects assigned to you yet."}
        </div>
      )}
    </div>
  );
}

function AddGroupButton({ projectId, onRefresh }) {
  const [show, setShow] = useState(false);
  const [name, setName] = useState("");

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    await groupAPI.create({ project_id: projectId, name: name.trim() });
    setName(""); setShow(false);
    onRefresh();
  };

  if (!show) return (
    <button className="btn btn-sm btn-outline" onClick={() => setShow(true)}>+ Add Group</button>
  );

  return (
    <form className="inline-form" style={{ margin: 0 }} onSubmit={handleAdd}>
      <input type="text" placeholder="Group name" value={name} autoFocus
        onChange={(e) => setName(e.target.value)} style={{ width: 150 }} />
      <button type="submit" className="btn btn-primary btn-sm">Add</button>
      <button type="button" className="btn btn-outline btn-sm" onClick={() => setShow(false)}>Cancel</button>
    </form>
  );
}

function GroupSection({ group, isAdmin, onRefresh }) {
  const [form, setForm] = useState({ fqdn: "", port: "443", network_type: "external", use_proxy: false });
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState("");
  const [editingGroup, setEditingGroup] = useState(null);
  const [editingFqdn, setEditingFqdn] = useState(null);
  const [showBulkImport, setShowBulkImport] = useState(false);

  const intranet = group.fqdns?.filter(f => f.network_type === "intranet") || [];
  const external = group.fqdns?.filter(f => f.network_type === "external") || [];

  const handleAdd = async (e) => {
    e.preventDefault();
    setError("");
    if (!form.fqdn.trim()) return;
    setAdding(true);
    try {
      await fqdnAPI.add({ group_id: group.id, ...form });
      setForm({ fqdn: "", port: "443", network_type: "external" });
      onRefresh();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to add FQDN");
    } finally {
      setAdding(false);
    }
  };

  const handleUpdateGroup = async (e) => {
    e.preventDefault();
    if (!editingGroup.name.trim()) return;
    await groupAPI.update(group.id, {
      name: editingGroup.name.trim(),
      alert_emails: editingGroup.alert_emails || "",
      cc_emails: editingGroup.cc_emails || "",
    });
    setEditingGroup(null);
    onRefresh();
  };

  const handleEditFqdn = async (e) => {
    e.preventDefault();
    if (!editingFqdn.fqdn.trim()) return;
    try {
      await fqdnAPI.edit(editingFqdn.id, {
        fqdn: editingFqdn.fqdn.trim(),
        port: editingFqdn.port,
        network_type: editingFqdn.network_type,
        use_proxy: editingFqdn.use_proxy,
      });
      setEditingFqdn(null);
      onRefresh();
    } catch (err) {
      setError(err.response?.data?.error || "Failed to edit FQDN");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Remove this FQDN?")) return;
    await fqdnAPI.delete(id);
    onRefresh();
  };

  const handleDeleteGroup = async () => {
    if (!window.confirm(`Delete group "${group.name}"?`)) return;
    await groupAPI.delete(group.id);
    onRefresh();
  };

  return (
    <div className="group-section">

      {/* Group Edit Modal */}
      {editingGroup && (
        <div className="modal-overlay" onClick={() => setEditingGroup(null)}>
          <div className="modal modal-lg" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Edit Group — {group.name}</h3>
              <button className="modal-close" onClick={() => setEditingGroup(null)}>×</button>
            </div>
            <form onSubmit={handleUpdateGroup}>
              <div className="form-group">
                <label>Group Name</label>
                <input type="text" value={editingGroup.name}
                  onChange={e => setEditingGroup({ ...editingGroup, name: e.target.value })}
                  required />
              </div>
              <EmailChipInput
                label="Alert Recipients (TO)"
                hint="overrides project-level recipients for this group"
                value={editingGroup.alert_emails}
                onChange={val => setEditingGroup({ ...editingGroup, alert_emails: val })}
                placeholder="user@example.com"
              />
              <EmailChipInput
                label="CC Recipients"
                hint="overrides project-level CC for this group"
                value={editingGroup.cc_emails}
                onChange={val => setEditingGroup({ ...editingGroup, cc_emails: val })}
                placeholder="manager@example.com"
              />
              <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                <button type="submit" className="btn btn-primary">Save Changes</button>
                <button type="button" className="btn btn-outline" onClick={() => setEditingGroup(null)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="group-section-header">
        <div>
          <span className="group-label">{group.name}</span>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 4 }}>
            {group.alert_emails && (
              <span className="email-summary-tag email-to">
                TO: {group.alert_emails.split(",").length} recipient{group.alert_emails.split(",").length > 1 ? "s" : ""}
              </span>
            )}
            {group.cc_emails && (
              <span className="email-summary-tag email-cc">
                CC: {group.cc_emails.split(",").length} recipient{group.cc_emails.split(",").length > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>
        {isAdmin && (
          <div style={{ display: "flex", gap: 6 }}>
            <button className="btn btn-sm btn-outline"
              onClick={() => setEditingGroup({
                name: group.name,
                alert_emails: group.alert_emails || "",
                cc_emails: group.cc_emails || "",
              })}>
              ✏️ Edit
            </button>
            <button className="btn btn-sm btn-danger-outline" onClick={handleDeleteGroup}>
              Delete Group
            </button>
          </div>
        )}
      </div>

      {/* Add FQDN */}
      {showBulkImport && (
        <BulkImportModal
          groupId={group.id}
          groupName={group.name}
          onClose={() => setShowBulkImport(false)}
          onRefresh={onRefresh}
        />
      )}

      <form className="add-fqdn-form" onSubmit={handleAdd}>
        <input type="text" placeholder="FQDN (e.g. example.com)"
          value={form.fqdn} onChange={e => setForm({ ...form, fqdn: e.target.value })} />
        <input type="number" placeholder="Port" value={form.port}
          onChange={e => setForm({ ...form, port: e.target.value })} style={{ width: "80px" }} />
        <select value={form.network_type} onChange={e => setForm({ ...form, network_type: e.target.value })}>
          <option value="intranet">Intranet</option>
          <option value="external">External</option>
        </select>
        <label className="proxy-toggle-label" title="Check via proxy server">
          <input type="checkbox" checked={form.use_proxy}
            onChange={e => setForm({ ...form, use_proxy: e.target.checked })} />
          Via Proxy
        </label>
        <button type="submit" className="btn btn-primary" disabled={adding}>
          {adding ? "Adding..." : "Add FQDN"}
        </button>
        {isAdmin && (
          <button type="button" className="btn btn-outline" onClick={() => setShowBulkImport(true)}>
            📋 Bulk Import
          </button>
        )}
      </form>
      {error && <div className="alert alert-error">{error}</div>}

      {/* Edit FQDN inline */}
      {editingFqdn && (
        <form className="edit-fqdn-form" onSubmit={handleEditFqdn}>
          <span className="edit-fqdn-label">Editing:</span>
          <input type="text" value={editingFqdn.fqdn}
            onChange={e => setEditingFqdn({ ...editingFqdn, fqdn: e.target.value })} autoFocus />
          <input type="number" value={editingFqdn.port} style={{ width: "80px" }}
            onChange={e => setEditingFqdn({ ...editingFqdn, port: e.target.value })} />
          <select value={editingFqdn.network_type}
            onChange={e => setEditingFqdn({ ...editingFqdn, network_type: e.target.value })}>
            <option value="intranet">Intranet</option>
            <option value="external">External</option>
          </select>
          <label className="proxy-toggle-label">
            <input type="checkbox" checked={!!editingFqdn.use_proxy}
              onChange={e => setEditingFqdn({ ...editingFqdn, use_proxy: e.target.checked })} />
            Via Proxy
          </label>
          <button type="submit" className="btn btn-primary btn-sm">Save</button>
          <button type="button" className="btn btn-outline btn-sm" onClick={() => setEditingFqdn(null)}>Cancel</button>
        </form>
      )}

      <div className="fqdn-panels">
        <FQDNEditTable title="Intranet" fqdns={intranet} isAdmin={isAdmin}
          editingId={editingFqdn?.id}
          onEdit={f => setEditingFqdn({ id: f.id, fqdn: f.fqdn, port: f.port, network_type: f.network_type, use_proxy: !!f.use_proxy })}
          onDelete={handleDelete} />
        <FQDNEditTable title="External" fqdns={external} isAdmin={isAdmin}
          editingId={editingFqdn?.id}
          onEdit={f => setEditingFqdn({ id: f.id, fqdn: f.fqdn, port: f.port, network_type: f.network_type, use_proxy: !!f.use_proxy })}
          onDelete={handleDelete} />
      </div>
    </div>
  );
}

function FQDNEditTable({ title, fqdns, isAdmin, editingId, onEdit, onDelete }) {
  return (
    <div className="fqdn-panel">
      <div className="panel-title">{title}</div>
      {fqdns.length === 0 ? (
        <div className="panel-empty">No {title.toLowerCase()} domains</div>
      ) : (
        <table className="fqdn-table">
          <thead>
            <tr>
              <th>FQDN</th>
              <th>Port</th>
              <th>Status</th>
              {isAdmin && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {fqdns.map(f => (
              <tr key={f.id} className={editingId === f.id ? "row-editing" : ""}>
                <td className="fqdn-cell">
                  {f.fqdn}
                  {!!f.use_proxy && <span className="proxy-badge" title="Checked via proxy">🔀 proxy</span>}
                  {f.last_error && (f.status === "Error" || f.status === "403 Proxy Blocked") && (
                    <div className="inline-error-text">⚠ {f.last_error}</div>
                  )}
                </td>
                <td>{f.port}</td>
                <td><StatusBadge status={f.status} error={f.last_error} /></td>
                {isAdmin && (
                  <td>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="btn btn-sm btn-outline" onClick={() => onEdit(f)}>✏️</button>
                      <button className="btn btn-sm btn-danger" onClick={() => onDelete(f.id)}>Delete</button>
                    </div>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
