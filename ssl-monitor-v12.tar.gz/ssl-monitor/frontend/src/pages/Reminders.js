import React, { useEffect, useState } from "react";
import { reminderAPI, projectAPI } from "../api";
import { toIST } from "../utils/time";

function daysUntil(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return Math.round((d - now) / (1000 * 60 * 60 * 24));
}

export default function Reminders() {
  const [reminders, setReminders] = useState([]);
  const [fqdns, setFqdns] = useState([]);
  const [projectList, setProjectList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: "", notes: "", remind_date: "", fqdn_id: "", project_id: "", email_to: "", email_cc: "" });

  const fetchAll = async () => {
    try {
      const [r, p] = await Promise.all([reminderAPI.getAll(), projectAPI.getAll()]);
      setReminders(r.data);
      setProjectList(p.data.map(proj => ({ id: proj.id, name: proj.name })));
      // flatten all fqdns for the dropdown
      const allFqdns = [];
      p.data.forEach(proj => proj.groups?.forEach(g => g.fqdns?.forEach(f =>
        allFqdns.push({ id: f.id, label: `${f.fqdn} (${proj.name})` })
      )));
      setFqdns(allFqdns);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const resetForm = () => {
    setForm({ title: "", notes: "", remind_date: "", fqdn_id: "", project_id: "", email_to: "", email_cc: "" });
    setEditing(null);
    setShowForm(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.remind_date) return;
    const payload = { ...form, fqdn_id: form.fqdn_id || null, project_id: form.project_id || null };
    if (editing) await reminderAPI.update(editing, payload);
    else await reminderAPI.create(payload);
    resetForm();
    fetchAll();
  };

  const handleEdit = (r) => {
    setForm({
      title: r.title, notes: r.notes || "", remind_date: r.remind_date,
      fqdn_id: r.fqdn_id || "", project_id: r.project_id || "",
      email_to: r.email_to || "", email_cc: r.email_cc || "",
    });
    setEditing(r.id);
    setShowForm(true);
  };

  const handleToggle = async (r) => {
    await reminderAPI.toggleDone(r.id, !r.done);
    fetchAll();
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this reminder?")) return;
    await reminderAPI.delete(id);
    fetchAll();
  };

  if (loading) return <div className="page-loading">Loading reminders...</div>;

  const active = reminders.filter(r => !r.done);
  const done = reminders.filter(r => r.done);

  const badge = (r) => {
    const d = daysUntil(r.remind_date);
    if (d < 0)  return <span className="reminder-badge overdue">Overdue {Math.abs(d)}d</span>;
    if (d === 0) return <span className="reminder-badge today">Today</span>;
    if (d <= 7) return <span className="reminder-badge soon">In {d}d</span>;
    return <span className="reminder-badge future">In {d}d</span>;
  };

  const renderRow = (r) => (
    <div key={r.id} className={`reminder-item ${r.done ? "reminder-done" : ""}`}>
      <div className="reminder-check">
        <input type="checkbox" checked={!!r.done} onChange={() => handleToggle(r)} title="Mark done" />
      </div>
      <div className="reminder-body">
        <div className="reminder-title-row">
          <span className="reminder-title">{r.title}</span>
          {!r.done && badge(r)}
        </div>
        <div className="reminder-meta">
          📅 {r.remind_date}
          {r.project_name && <> · 📁 {r.project_name}</>}
          {r.fqdn_name && <> · 🔗 {r.fqdn_name}</>}
          {r.email_to && <> · ✉️ {r.email_to}</>}
          {r.email_cc && <> · CC: {r.email_cc}</>}
        </div>
        {r.notes && <div className="reminder-notes">{r.notes}</div>}
      </div>
      <div className="reminder-actions">
        <button className="btn-icon" onClick={() => handleEdit(r)} title="Edit">✏️</button>
        <button className="btn-icon" onClick={() => handleDelete(r.id)} title="Delete">🗑️</button>
      </div>
    </div>
  );

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Reminders</h1>
          <p className="page-subtitle">{active.length} active · {done.length} completed</p>
        </div>
        <button className="btn btn-primary" onClick={() => { resetForm(); setShowForm(!showForm); }}>
          + New Reminder
        </button>
      </div>

      <div className="info-banner">
        Reminders alert by email using the same schedule as SSL certificate alerts — advance warnings at your configured thresholds (e.g. 30/14/7 days before), sent at the daily alert time, repeating daily once close. Configure thresholds in Settings → Alerts.
      </div>

      {showForm && (
        <div className="settings-card" style={{ marginBottom: 24 }}>
          <div className="settings-card-title">
            <span className="settings-icon">🔔</span> {editing ? "Edit Reminder" : "New Reminder"}
          </div>
          <div className="settings-card-body">
            <form onSubmit={handleSubmit}>
              <div className="form-row-2">
                <div className="form-group">
                  <label>Title *</label>
                  <input type="text" value={form.title}
                    onChange={e => setForm({ ...form, title: e.target.value })}
                    placeholder="e.g. Renew wildcard cert manually" required />
                </div>
                <div className="form-group">
                  <label>Remind Date *</label>
                  <input type="date" value={form.remind_date}
                    onChange={e => setForm({ ...form, remind_date: e.target.value })} required />
                </div>
              </div>
              <div className="form-row-2">
                <div className="form-group">
                  <label>Project <span className="label-hint">(optional)</span></label>
                  <select className="form-select" value={form.project_id}
                    onChange={e => setForm({ ...form, project_id: e.target.value })}>
                    <option value="">— None —</option>
                    {projectList.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Link to Domain <span className="label-hint">(optional)</span></label>
                  <select className="form-select" value={form.fqdn_id}
                    onChange={e => setForm({ ...form, fqdn_id: e.target.value })}>
                    <option value="">— None —</option>
                    {fqdns.map(f => <option key={f.id} value={f.id}>{f.label}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-row-2">
                <div className="form-group">
                  <label>Email To <span className="label-hint">(uses global CC if empty)</span></label>
                  <input type="text" value={form.email_to}
                    onChange={e => setForm({ ...form, email_to: e.target.value })}
                    placeholder="you@example.com" />
                </div>
                <div className="form-group">
                  <label>CC <span className="label-hint">(optional)</span></label>
                  <input type="text" value={form.email_cc}
                    onChange={e => setForm({ ...form, email_cc: e.target.value })}
                    placeholder="manager@example.com, team@example.com" />
                </div>
              </div>
              <div className="form-group">
                <label>Notes <span className="label-hint">(optional)</span></label>
                <textarea value={form.notes}
                  onChange={e => setForm({ ...form, notes: e.target.value })}
                  placeholder="Any details..."
                  style={{ width: "100%", minHeight: 70, padding: 10, border: "1px solid var(--border)", borderRadius: 6, fontSize: 14, fontFamily: "inherit", resize: "vertical" }} />
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button type="submit" className="btn btn-primary">{editing ? "Save Changes" : "Create Reminder"}</button>
                <button type="button" className="btn btn-outline" onClick={resetForm}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {reminders.length === 0 ? (
        <div className="empty-state">No reminders yet. Click "New Reminder" to add one.</div>
      ) : (
        <>
          {active.length > 0 && (
            <div className="reminder-section">
              <div className="reminder-section-title">Active</div>
              {active.map(renderRow)}
            </div>
          )}
          {done.length > 0 && (
            <div className="reminder-section">
              <div className="reminder-section-title">Completed</div>
              {done.map(renderRow)}
            </div>
          )}
        </>
      )}
    </div>
  );
}
