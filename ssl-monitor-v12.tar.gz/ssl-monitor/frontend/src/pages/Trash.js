import React, { useEffect, useState } from "react";
import { trashAPI } from "../api";
import { timeAgo } from "../utils/time";

export default function Trash() {
  const [data, setData] = useState({ projects: [], groups: [], fqdns: [] });
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState({ type: "", text: "" });

  const fetchTrash = async () => {
    try {
      const res = await trashAPI.getAll();
      setData(res.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchTrash(); }, []);

  const handleRestore = async (type, id, name) => {
    try {
      await trashAPI.restore(type, id);
      setMsg({ type: "success", text: `"${name}" restored successfully` });
      fetchTrash();
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.error || "Restore failed" });
    }
  };

  const handleDelete = async (type, id, name) => {
    if (!window.confirm(`Permanently delete "${name}"? This cannot be undone.`)) return;
    try {
      await trashAPI.deletePermanent(type, id);
      setMsg({ type: "success", text: `"${name}" permanently deleted` });
      fetchTrash();
    } catch (err) {
      setMsg({ type: "error", text: err.response?.data?.error || "Delete failed" });
    }
  };

  const handleEmptyTrash = async () => {
    if (!window.confirm("Permanently delete ALL items in trash? This cannot be undone.")) return;
    try {
      await trashAPI.empty();
      setMsg({ type: "success", text: "Trash emptied" });
      fetchTrash();
    } catch (err) {
      setMsg({ type: "error", text: "Failed to empty trash" });
    }
  };

  const total = data.projects.length + data.groups.length + data.fqdns.length;

  const daysLeft = (dateStr) => {
    const utc = dateStr.includes("T") ? dateStr : dateStr.replace(" ", "T") + "Z";
    const diff = 30 - Math.floor((Date.now() - new Date(utc).getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  if (loading) return <div className="page-loading">Loading trash...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>🗑️ Trash</h1>
          <p className="page-subtitle">
            Deleted items are kept for 30 days before permanent deletion.
          </p>
        </div>
        {total > 0 && (
          <button className="btn btn-danger" onClick={handleEmptyTrash}>
            Empty Trash ({total})
          </button>
        )}
      </div>

      {msg.text && (
        <div className={`alert ${msg.type === "success" ? "alert-success" : "alert-error"}`}
          style={{ marginBottom: 16 }}>
          {msg.text}
        </div>
      )}

      {total === 0 ? (
        <div className="trash-empty">
          <div className="trash-empty-icon">🗑️</div>
          <div className="trash-empty-title">Trash is empty</div>
          <div className="trash-empty-sub">Deleted projects, groups and FQDNs will appear here</div>
        </div>
      ) : (
        <>
          {/* Projects */}
          {data.projects.length > 0 && (
            <TrashSection
              title="Projects" icon="📁" items={data.projects}
              renderName={i => i.name}
              renderMeta={i => `Deleted ${timeAgo(i.deleted_at)} · ${daysLeft(i.deleted_at)}d until permanent deletion`}
              onRestore={i => handleRestore("project", i.id, i.name)}
              onDelete={i => handleDelete("project", i.id, i.name)}
            />
          )}

          {/* Groups */}
          {data.groups.length > 0 && (
            <TrashSection
              title="Groups" icon="📂" items={data.groups}
              renderName={i => i.name}
              renderMeta={i => `In project: ${i.project_name} · Deleted ${timeAgo(i.deleted_at)} · ${daysLeft(i.deleted_at)}d left`}
              onRestore={i => handleRestore("group", i.id, i.name)}
              onDelete={i => handleDelete("group", i.id, i.name)}
            />
          )}

          {/* FQDNs */}
          {data.fqdns.length > 0 && (
            <TrashSection
              title="FQDNs" icon="🔒" items={data.fqdns}
              renderName={i => i.fqdn}
              renderMeta={i => `${i.project_name} › ${i.group_name} · Port ${i.port} · Deleted ${timeAgo(i.deleted_at)} · ${daysLeft(i.deleted_at)}d left`}
              onRestore={i => handleRestore("fqdn", i.id, i.fqdn)}
              onDelete={i => handleDelete("fqdn", i.id, i.fqdn)}
            />
          )}
        </>
      )}
    </div>
  );
}

function TrashSection({ title, icon, items, renderName, renderMeta, onRestore, onDelete }) {
  return (
    <div className="trash-section">
      <div className="trash-section-title">
        <span>{icon}</span> {title} <span className="trash-count">{items.length}</span>
      </div>
      {items.map(item => (
        <div key={item.id} className="trash-item">
          <div className="trash-item-info">
            <div className="trash-item-name">{renderName(item)}</div>
            <div className="trash-item-meta">{renderMeta(item)}</div>
          </div>
          <div className="trash-item-actions">
            <button className="btn btn-sm btn-outline" onClick={() => onRestore(item)}
              title="Restore this item">
              ↩️ Restore
            </button>
            <button className="btn btn-sm btn-danger" onClick={() => onDelete(item)}
              title="Permanently delete">
              Delete Forever
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
