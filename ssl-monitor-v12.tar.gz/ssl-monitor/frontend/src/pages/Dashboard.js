import React, { useEffect, useState } from "react";
import { projectAPI, fqdnAPI, reminderAPI } from "../api";
import { useAuth } from "../context/AuthContext";
import StatusBadge from "../components/StatusBadge";

export default function Dashboard() {
  const { isReadonly } = useAuth();
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [lastChecked, setLastChecked] = useState(null);
  const [activeProjectId, setActiveProjectId] = useState(null);
  const [search, setSearch] = useState("");
  const [activeReminders, setActiveReminders] = useState([]);
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("default");

  const fetchProjects = async () => {
    try {
      const res = await projectAPI.getAll();
      setProjects(res.data);
      setActiveProjectId(prev => {
        if (prev && res.data.some(p => p.id === prev)) return prev;
        return res.data.length ? res.data[0].id : null;
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await fetchProjects();
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchProjects();
    reminderAPI.getActive().then(r => setActiveReminders(r.data)).catch(() => {});
    // Auto-refresh every 5 minutes
    const interval = setInterval(fetchProjects, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const handleCheckAll = async () => {
    setChecking(true);
    try {
      await fqdnAPI.checkAll();
      // Wait a few seconds for backend to process, then refresh
      setTimeout(async () => {
        await fetchProjects();
        setLastChecked(new Date().toLocaleTimeString());
        setChecking(false);
      }, 5000);
    } catch (err) {
      setChecking(false);
    }
  };

  const getStats = () => {
    let total = 0, ok = 0, warn = 0, error = 0;
    projects.forEach((p) =>
      p.groups?.forEach((g) =>
        g.fqdns?.forEach((f) => {
          total++;
          if (f.status === "OK") ok++;
          else if (f.status === "Warning" || f.status === "Critical") warn++;
          else if (f.status === "Error" || f.status === "Expired") error++;
        })
      )
    );
    return { total, ok, warn, error };
  };

  const stats = getStats();

  if (loading) return <div className="page-loading">Loading dashboard...</div>;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Dashboard</h1>
        <div className="header-actions">
          {lastChecked && <span className="last-checked">Last checked: {lastChecked}</span>}
          {!isReadonly() && (
            <button
              className="btn btn-primary"
              onClick={handleCheckAll}
              disabled={checking}
            >
              {checking ? "Checking..." : "🔄 Check All Now"}
            </button>
          )}
          <button className="btn btn-outline" onClick={handleRefresh} disabled={refreshing}>
            {refreshing ? "Refreshing..." : "↻ Refresh"}
          </button>
        </div>
      </div>

      {/* Search bar */}
      <div className="dashboard-search">
        <span className="dashboard-search-icon">🔍</span>
        <input
          type="text"
          className="dashboard-search-input"
          placeholder="Search domains across all projects..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {search && (
          <button className="dashboard-search-clear" onClick={() => setSearch("")} title="Clear">×</button>
        )}
      </div>

      {/* Reminder banner — due/upcoming reminders */}
      {activeReminders.length > 0 && (
        <div className="reminder-banner">
          <div className="reminder-banner-title">🔔 Upcoming Reminders ({activeReminders.length})</div>
          {activeReminders.slice(0, 5).map(r => (
            <div key={r.id} className="reminder-banner-item">
              <span className="reminder-banner-date">{r.remind_date}</span> — {r.title}
              {r.fqdn_name && <> (🔗 {r.fqdn_name})</>}
            </div>
          ))}
        </div>
      )}

      {/* Summary Stats */}
      <div className="stats-row">
        <div className={`stat-card stat-clickable ${statusFilter === "all" ? "stat-active" : ""}`}
          onClick={() => setStatusFilter("all")}>
          <div className="stat-num">{stats.total}</div>
          <div className="stat-label">Total Domains</div>
        </div>
        <div className={`stat-card stat-ok stat-clickable ${statusFilter === "ok" ? "stat-active" : ""}`}
          onClick={() => setStatusFilter("ok")}>
          <div className="stat-num">{stats.ok}</div>
          <div className="stat-label">OK</div>
        </div>
        <div className={`stat-card stat-warn stat-clickable ${statusFilter === "warn" ? "stat-active" : ""}`}
          onClick={() => setStatusFilter("warn")}>
          <div className="stat-num">{stats.warn}</div>
          <div className="stat-label">Warning / Critical</div>
        </div>
        <div className={`stat-card stat-error stat-clickable ${statusFilter === "error" ? "stat-active" : ""}`}
          onClick={() => setStatusFilter("error")}>
          <div className="stat-num">{stats.error}</div>
          <div className="stat-label">Error / Expired</div>
        </div>
      </div>

      {/* Filter + Sort controls */}
      <div className="dash-controls">
        <div className="dash-filter-info">
          {statusFilter !== "all" && (
            <span className="dash-active-filter">
              Filter: <strong>{statusFilter === "ok" ? "OK" : statusFilter === "warn" ? "Warning/Critical" : "Error/Expired"}</strong>
              <button onClick={() => setStatusFilter("all")} className="dash-filter-clear">×</button>
            </span>
          )}
        </div>
        <div className="dash-sort">
          <label>Sort by:</label>
          <select value={sortBy} onChange={e => setSortBy(e.target.value)} className="dash-sort-select">
            <option value="default">Default</option>
            <option value="days_asc">Days Left (least first)</option>
            <option value="days_desc">Days Left (most first)</option>
            <option value="name">Name (A–Z)</option>
            <option value="rt_desc">Response Time (slowest)</option>
          </select>
        </div>
      </div>

      {/* Project Tabs — hidden while searching */}
      {projects.length > 0 && !search.trim() && (
        <div className="settings-tabs project-tabs-bar">
          {projects.map((project) => (
            <button key={project.id}
              className={`settings-tab ${activeProjectId === project.id ? "active" : ""}`}
              onClick={() => setActiveProjectId(project.id)}>
              {project.name}
            </button>
          ))}
        </div>
      )}

      {/* Projects — filtered by search, or active tab */}
      {(() => {
        const q = search.trim().toLowerCase();
        const filterActive = q || statusFilter !== "all";
        // When searching or filtering, show all projects; otherwise just the active tab
        const visibleProjects = filterActive
          ? projects
          : projects.filter(p => p.id === activeProjectId);

        // Filter FQDNs by search query
        const matchFqdn = (f) => {
          if (q && !f.fqdn.toLowerCase().includes(q)) return false;
          if (statusFilter === "ok" && f.status !== "OK") return false;
          if (statusFilter === "warn" && !["Warning", "Critical"].includes(f.status)) return false;
          if (statusFilter === "error" && !["Error", "Expired", "403 Proxy Blocked"].includes(f.status)) return false;
          return true;
        };

        const sortFqdns = (arr) => {
          const sorted = [...arr];
          if (sortBy === "days_asc") sorted.sort((a, b) => (a.days_left ?? 99999) - (b.days_left ?? 99999));
          else if (sortBy === "days_desc") sorted.sort((a, b) => (b.days_left ?? -99999) - (a.days_left ?? -99999));
          else if (sortBy === "name") sorted.sort((a, b) => a.fqdn.localeCompare(b.fqdn));
          else if (sortBy === "rt_desc") sorted.sort((a, b) => (b.response_time_ms ?? -1) - (a.response_time_ms ?? -1));
          return sorted;
        };

        let anyMatch = false;

        const rendered = visibleProjects.map((project) => {
          const groupsWithMatches = (project.groups || []).map((group) => {
            const intranet = sortFqdns((group.fqdns || []).filter((f) => f.network_type === "intranet" && matchFqdn(f)));
            const external = sortFqdns((group.fqdns || []).filter((f) => f.network_type === "external" && matchFqdn(f)));
            return { group, intranet, external };
          }).filter(g => !filterActive || g.intranet.length || g.external.length);

          if (filterActive && groupsWithMatches.length === 0) return null;
          if (groupsWithMatches.length) anyMatch = true;

          return (
            <div key={project.id} className="project-block">
              <div className="project-title">{project.name}</div>
              {groupsWithMatches.map(({ group, intranet, external }) => (
                <div key={group.id} className="group-block">
                  <div className="group-name">{group.name}</div>
                  <div className="fqdn-panels">
                    <FQDNTable title="Intranet" fqdns={intranet} onRefresh={fetchProjects} readonly={isReadonly()} />
                    <FQDNTable title="External" fqdns={external} onRefresh={fetchProjects} readonly={isReadonly()} />
                  </div>
                </div>
              ))}
            </div>
          );
        });

        if (filterActive && !anyMatch) {
          return <div className="empty-state">No domains match the current filter{search ? ` "${search}"` : ""}</div>;
        }
        return rendered;
      })()}

      {projects.length === 0 && (
        <div className="empty-state">
          No projects yet. Go to Projects to add domains.
        </div>
      )}
    </div>
  );
}

function FQDNTable({ title, fqdns, onRefresh, readonly }) {
  const [checking, setChecking] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [selected, setSelected] = useState([]);
  const [bulkBusy, setBulkBusy] = useState(false);

  const handleCheck = async (id) => {
    setChecking(id);
    try {
      await fqdnAPI.checkOne(id);
      await onRefresh();
    } finally {
      setChecking(null);
    }
  };

  const toggleExpand = (id) => setExpandedId(expandedId === id ? null : id);

  const toggleSelect = (id) => setSelected(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const toggleSelectAll = () => setSelected(prev =>
    prev.length === fqdns.length ? [] : fqdns.map(f => f.id));

  const handleBulkRecheck = async () => {
    setBulkBusy(true);
    try {
      await fqdnAPI.bulkRecheck(selected);
      setTimeout(async () => { await onRefresh(); setSelected([]); setBulkBusy(false); }, 3000);
    } catch { setBulkBusy(false); }
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`Delete ${selected.length} selected domain(s)? They will move to Trash.`)) return;
    setBulkBusy(true);
    try {
      await fqdnAPI.bulkDelete(selected);
      await onRefresh();
      setSelected([]);
    } finally { setBulkBusy(false); }
  };

  return (
    <div className="fqdn-panel">
      <div className="panel-title">{title}</div>
      {fqdns.length === 0 ? (
        <div className="panel-empty">No {title.toLowerCase()} domains</div>
      ) : (
        <>
        {!readonly && selected.length > 0 && (
          <div className="bulk-bar">
            <span className="bulk-count">{selected.length} selected</span>
            <button className="btn btn-sm btn-outline" onClick={handleBulkRecheck} disabled={bulkBusy}>
              {bulkBusy ? "Working..." : "🔍 Re-check"}
            </button>
            <button className="btn btn-sm btn-danger" onClick={handleBulkDelete} disabled={bulkBusy}>
              🗑️ Delete
            </button>
            <button className="btn btn-sm btn-link" onClick={() => setSelected([])}>Clear</button>
          </div>
        )}
        <table className="fqdn-table">
          <thead>
            <tr>
              {!readonly && (
                <th style={{ width: 30 }}>
                  <input type="checkbox"
                    checked={selected.length === fqdns.length && fqdns.length > 0}
                    onChange={toggleSelectAll} title="Select all" />
                </th>
              )}
              <th>FQDN</th>
              <th>Port</th>
              <th>Expiry Date</th>
              <th>Days Left</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {fqdns.map((f) => (
              <React.Fragment key={f.id}>
              <tr className={f.status === "Error" || f.status === "Expired" ? "row-error" : ""}>
                {!readonly && (
                  <td style={{ width: 30 }}>
                    <input type="checkbox" checked={selected.includes(f.id)} onChange={() => toggleSelect(f.id)} />
                  </td>
                )}
                <td className="fqdn-cell">
                  <span className="fqdn-expand-toggle" onClick={() => toggleExpand(f.id)} title="View certificate details">
                    {expandedId === f.id ? "▾" : "▸"} {f.fqdn}
                  </span>
                  {f.cert_changed_at && (
                    <span className="cert-changed-badge" title={`Certificate changed — detected ${f.cert_changed_at}`}>🔄 changed</span>
                  )}
                  {f.last_error && (f.status === "Error" || f.status === "403 Proxy Blocked") && (
                    <div className="inline-error-text">⚠ {f.last_error}</div>
                  )}
                </td>
                <td>{f.port}</td>
                <td>{f.expiry_date ? f.expiry_date.slice(0, 10) : "—"}</td>
                <td>
                  {f.days_left !== null ? (
                    <span className={
                      f.days_left <= 14 ? "days-critical" :
                      f.days_left <= 30 ? "days-warning" : ""
                    }>
                      {f.days_left}
                    </span>
                  ) : "—"}
                </td>
                <td><StatusBadge status={f.status} error={f.last_error} /></td>
                <td>
                  {!readonly && (
                    <button
                      className="btn-icon"
                      title="Check now"
                      onClick={() => handleCheck(f.id)}
                      disabled={checking === f.id}
                    >
                      {checking === f.id ? "⏳" : "🔍"}
                    </button>
                  )}
                </td>
              </tr>
              {expandedId === f.id && (
                <tr className="cert-detail-row">
                  <td colSpan={readonly ? 6 : 7}>
                    <div className="cert-detail-grid">
                      <div className="cert-detail-item">
                        <span className="cert-detail-label">Issuer (CA)</span>
                        <span className="cert-detail-value">{f.issuer || "—"}</span>
                      </div>
                      <div className="cert-detail-item">
                        <span className="cert-detail-label">Subject CN</span>
                        <span className="cert-detail-value">{f.subject_cn || "—"}</span>
                      </div>
                      <div className="cert-detail-item">
                        <span className="cert-detail-label">Valid From</span>
                        <span className="cert-detail-value">{f.valid_from || "—"}</span>
                      </div>
                      <div className="cert-detail-item">
                        <span className="cert-detail-label">Chain</span>
                        <span className="cert-detail-value">
                          {f.chain_valid === 1 ? (
                            <span className="chain-ok">✓ Valid</span>
                          ) : f.chain_valid === 0 ? (
                            <span className="chain-bad" title={f.chain_error || ""}>✗ {f.chain_error || "Invalid"}</span>
                          ) : "—"}
                        </span>
                      </div>
                      <div className="cert-detail-item">
                        <span className="cert-detail-label">Protocol</span>
                        <span className="cert-detail-value">{f.protocol || "—"} {f.cipher ? `· ${f.cipher}` : ""}</span>
                      </div>
                      <div className="cert-detail-item">
                        <span className="cert-detail-label">Response Time</span>
                        <span className="cert-detail-value">
                          {f.response_time_ms !== null && f.response_time_ms !== undefined ? (
                            <span className={f.response_time_ms > 2000 ? "rt-slow" : f.response_time_ms > 800 ? "rt-med" : "rt-fast"}>
                              {f.response_time_ms} ms
                            </span>
                          ) : "—"}
                        </span>
                      </div>
                      <div className="cert-detail-item cert-detail-full">
                        <span className="cert-detail-label">SAN (Subject Alt Names)</span>
                        <span className="cert-detail-value cert-san">{f.san || "—"}</span>
                      </div>
                      {f.cert_changed_at && (
                        <div className="cert-detail-item cert-detail-full cert-changed-panel">
                          <span className="cert-detail-label">🔄 Certificate Changed</span>
                          <span className="cert-detail-value" style={{ fontFamily: "inherit" }}>
                            Detected {f.cert_changed_at}
                            {f.prev_expiry_date && <> · previous expiry was <strong>{f.prev_expiry_date}</strong></>}
                            {f.prev_issuer && f.prev_issuer !== f.issuer && <> · previous issuer: {f.prev_issuer}</>}
                          </span>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
        </>
      )}
    </div>
  );
}
