import axios from "axios";

const BASE = process.env.REACT_APP_API_URL || "";
const api = axios.create({ baseURL: `${BASE}/api` });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("ssl_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    // Don't redirect on 401 from the login endpoint — let the form show the error
    const isLoginRequest = err.config?.url?.includes("/auth/login");
    if (err.response?.status === 401 && !isLoginRequest) {
      localStorage.removeItem("ssl_token");
      localStorage.removeItem("ssl_user");
      localStorage.removeItem("ssl_role");
      window.location.href = "/";
    }
    return Promise.reject(err);
  }
);

export const authAPI = {
  login: (data) => api.post("/auth/login", data),
  changePassword: (data) => api.post("/auth/change-password", data),
  getUsers: () => api.get("/auth/users"),
  createUser: (data) => api.post("/auth/users", data),
  updateUser: (id, data) => api.put(`/auth/users/${id}`, data),
  deleteUser: (id) => api.delete(`/auth/users/${id}`),
};

export const projectAPI = {
  getAll: () => api.get("/projects"),
  create: (data) => api.post("/projects", data),
  update: (id, data) => api.put(`/projects/${id}`, data),
  delete: (id) => api.delete(`/projects/${id}`),
};

export const groupAPI = {
  create: (data) => api.post("/groups", data),
  update: (id, data) => api.put(`/groups/${id}`, data),
  delete: (id) => api.delete(`/groups/${id}`),
};

export const fqdnAPI = {
  bulkImport: (group_id, entries) => api.post("/fqdns/bulk-import", { group_id, entries }),
  bulkRecheck: (ids) => api.post("/fqdns/bulk-recheck", { ids }),
  bulkDelete: (ids) => api.post("/fqdns/bulk-delete", { ids }),
  add: (data) => api.post("/fqdns", data),
  edit: (id, data) => api.put(`/fqdns/${id}`, data),
  delete: (id) => api.delete(`/fqdns/${id}`),
  checkOne: (id) => api.post(`/fqdns/${id}/check`),
  checkAll: () => api.post("/fqdns/check-all"),
};

export const settingsAPI = {
  get: () => api.get("/settings"),
  update: (data) => api.patch("/settings", data),
  testEmail: (to) => api.post("/settings/test-email", { to }),
  testLdap: () => api.post("/settings/test-ldap"),
  cronStatus: () => api.get("/settings/cron-status"),
  runSSLCheckNow: () => api.post("/fqdns/check-all"),
  runAlertNow: () => api.post("/settings/run-alert"),
};

export const trashAPI = {
  getAll: () => api.get("/trash"),
  getCount: () => api.get("/trash/count"),
  restore: (type, id) => api.post(`/trash/restore/${type}/${id}`),
  deletePermanent: (type, id) => api.delete(`/trash/${type}/${id}`),
  empty: () => api.delete("/trash/empty"),
};

export const reminderAPI = {
  getAll: () => api.get("/reminders"),
  getActive: () => api.get("/reminders/active"),
  create: (data) => api.post("/reminders", data),
  update: (id, data) => api.put(`/reminders/${id}`, data),
  toggleDone: (id, done) => api.patch(`/reminders/${id}/done`, { done }),
  delete: (id) => api.delete(`/reminders/${id}`),
};

export const activityAPI = {
  getAll: (params = {}) => api.get("/activity", { params }),
  clear: () => api.delete("/activity"),
};

export default api;
