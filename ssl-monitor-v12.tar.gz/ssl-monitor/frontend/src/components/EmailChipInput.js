import React, { useState, useRef } from "react";

export default function EmailChipInput({ label, hint, value, onChange, placeholder }) {
  const [input, setInput] = useState("");
  const [error, setError] = useState("");
  const inputRef = useRef();

  // value is comma-separated string, convert to array
  const chips = value ? value.split(",").map(e => e.trim()).filter(Boolean) : [];

  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const addChip = (raw) => {
    const email = raw.trim().toLowerCase();
    if (!email) return;
    if (!isValidEmail(email)) { setError(`"${email}" is not a valid email`); return; }
    if (chips.includes(email)) { setError(`"${email}" already added`); return; }
    setError("");
    onChange([...chips, email].join(","));
    setInput("");
  };

  const removeChip = (chip) => {
    onChange(chips.filter(c => c !== chip).join(","));
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === "," || e.key === " ") {
      e.preventDefault();
      addChip(input);
    } else if (e.key === "Backspace" && !input && chips.length) {
      removeChip(chips[chips.length - 1]);
    }
  };

  const handleBlur = () => {
    if (input.trim()) addChip(input);
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData("text");
    const emails = pasted.split(/[,;\s\n]+/).filter(Boolean);
    const valid = [];
    emails.forEach(email => {
      const e = email.trim().toLowerCase();
      if (isValidEmail(e) && !chips.includes(e)) valid.push(e);
    });
    if (valid.length) {
      onChange([...chips, ...valid].join(","));
      setInput("");
    }
  };

  return (
    <div className="email-chip-field">
      {label && (
        <label className="email-chip-label">
          {label}
          {hint && <span className="label-hint"> — {hint}</span>}
        </label>
      )}
      <div
        className="email-chip-box"
        onClick={() => inputRef.current?.focus()}
      >
        {chips.map((chip) => (
          <span key={chip} className="email-chip">
            <span className="email-chip-icon">@</span>
            {chip}
            <button
              type="button"
              className="email-chip-remove"
              onClick={(e) => { e.stopPropagation(); removeChip(chip); }}
              title="Remove"
            >×</button>
          </span>
        ))}
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => { setInput(e.target.value); setError(""); }}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          onPaste={handlePaste}
          placeholder={chips.length === 0 ? (placeholder || "user@example.com") : "Add more..."}
          className="email-chip-input"
        />
      </div>
      {error && <div className="email-chip-error">{error}</div>}
      {chips.length > 0 && (
        <div className="email-chip-count">{chips.length} recipient{chips.length > 1 ? "s" : ""}</div>
      )}
    </div>
  );
}
