import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { authAPI, trashAPI } from "../api";

export default function Navbar({ activePage, setActivePage }) {
  const { user, logout, isAdmin, isReadonly } = useAuth();
  const [trashCount, setTrashCount] = useState(0);

  useEffect(() => {
    if (isAdmin()) {
      trashAPI.getCount().then(r => setTrashCount(r.data.count)).catch(() => {});
      const interval = setInterval(() => {
        trashAPI.getCount().then(r => setTrashCount(r.data.count)).catch(() => {});
      }, 30000);
      return () => clearInterval(interval);
    }
  }, []);
  const [showModal, setShowModal] = useState(false);
  const [pwForm, setPwForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [pwMsg, setPwMsg] = useState("");
  const [pwErr, setPwErr] = useState("");

  const handleChangePassword = async (e) => {
    e.preventDefault();
    setPwErr(""); setPwMsg("");
    if (pwForm.newPassword !== pwForm.confirm) { setPwErr("Passwords do not match"); return; }
    try {
      await authAPI.changePassword({ currentPassword: pwForm.currentPassword, newPassword: pwForm.newPassword });
      setPwMsg("Password changed!");
      setPwForm({ currentPassword: "", newPassword: "", confirm: "" });
    } catch (err) {
      setPwErr(err.response?.data?.error || "Failed");
    }
  };

  return (
    <>
      <nav className="navbar">
        <div className="navbar-brand">
          <svg width="24" height="24" viewBox="0 0 32 32" fill="none">
            <rect width="32" height="32" rx="8" fill="#2563eb"/>
            <path d="M16 6L8 10v6c0 5.5 3.5 10.7 8 12 4.5-1.3 8-6.5 8-12v-6L16 6z" fill="white"/>
          </svg>
          SSL Monitor
        </div>
        <div className="navbar-links">
          {["dashboard","projects"].map((p) => (
            <button key={p} className={`nav-link ${activePage === p ? "active" : ""}`}
              onClick={() => setActivePage(p)}>
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
          <button className={`nav-link ${activePage === "reminders" ? "active" : ""}`}
            onClick={() => setActivePage("reminders")}>
            🔔 Reminders
          </button>
          {isAdmin() && (
            <>
              <button className={`nav-link ${activePage === "users" ? "active" : ""}`}
                onClick={() => setActivePage("users")}>Users</button>
              <button className={`nav-link ${activePage === "settings" ? "active" : ""}`}
                onClick={() => setActivePage("settings")}>Settings</button>
              <button className={`nav-link ${activePage === "activity" ? "active" : ""}`}
                onClick={() => setActivePage("activity")}>
                📋 Activity
              </button>
              <button className={`nav-link trash-nav-btn ${activePage === "trash" ? "active" : ""}`}
                onClick={() => setActivePage("trash")}>
                🗑️
                {trashCount > 0 && <span className="trash-nav-badge">{trashCount}</span>}
              </button>
            </>
          )}
        </div>
        <div className="navbar-actions">
          <span className="nav-user">
            {user?.email || user?.username}
            <span className={`role-badge ${user?.role === "admin" ? "role-admin" : user?.role === "readonly" ? "role-readonly" : "role-user"}`}>
              {user?.role}
            </span>
          </span>
          <button className="nav-link" onClick={() => setShowModal(true)}>Change Password</button>
          <button className="nav-link" onClick={logout}>Logout</button>
        </div>
      </nav>

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h3>Change Password</h3>
              <button className="modal-close" onClick={() => setShowModal(false)}>×</button>
            </div>
            <form onSubmit={handleChangePassword}>
              {pwErr && <div className="alert alert-error">{pwErr}</div>}
              {pwMsg && <div className="alert alert-success">{pwMsg}</div>}
              {["currentPassword","newPassword","confirm"].map((field, i) => (
                <div key={field} className="form-group">
                  <label>{["Current Password","New Password","Confirm New Password"][i]}</label>
                  <input type="password" value={pwForm[field]}
                    onChange={(e) => setPwForm({ ...pwForm, [field]: e.target.value })} required />
                </div>
              ))}
              <button type="submit" className="btn btn-primary btn-full">Update Password</button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
