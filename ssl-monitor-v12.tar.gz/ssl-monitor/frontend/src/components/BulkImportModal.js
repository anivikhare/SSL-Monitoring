import React, { useState, useRef } from "react";
import { fqdnAPI } from "../api";

const SAMPLE_CSV = `fqdn,port,type,proxy
example.com,443,external,false
internal.example.com,443,intranet,false
dev.azure.com,443,external,true`;

function parseCSV(text) {
  const lines = text.trim().split("\n").filter(Boolean);
  if (!lines.length) return [];

  // Check if first line is header
  const firstLower = lines[0].toLowerCase();
  const hasHeader = firstLower.includes("fqdn") || firstLower.includes("domain") || firstLower.includes("host");
  const dataLines = hasHeader ? lines.slice(1) : lines;

  return dataLines.map(line => {
    // Support comma or tab separated
    const parts = line.split(/[,\t]/).map(p => p.trim().replace(/^["']|["']$/g, ""));
    const fqdn = parts[0] || "";
    const port = parseInt(parts[1]) || 443;
    const network_type = (parts[2] || "external").toLowerCase().includes("intra") ? "intranet" : "external";
    const use_proxy = (parts[3] || "").toLowerCase() === "true" || (parts[3] || "") === "1";
    return { fqdn: fqdn.toLowerCase().trim(), port, network_type, use_proxy };
  }).filter(e => e.fqdn);
}

export default function BulkImportModal({ groupId, groupName, onClose, onRefresh }) {
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState([]);
  const [result, setResult] = useState(null);
  const [importing, setImporting] = useState(false);
  const [tab, setTab] = useState("paste"); // paste | file
  const fileRef = useRef();

  const handleParse = (raw) => {
    setText(raw);
    const entries = parseCSV(raw);
    setParsed(entries);
    setResult(null);
  };

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => handleParse(ev.target.result);
    reader.readAsText(file);
    setTab("paste");
  };

  const handleImport = async () => {
    if (!parsed.length) return;
    setImporting(true);
    try {
      const res = await fqdnAPI.bulkImport(groupId, parsed);
      setResult(res.data);
      if (res.data.imported.length > 0) onRefresh();
    } catch (err) {
      setResult({ error: err.response?.data?.error || "Import failed" });
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal modal-lg" style={{ width: 600 }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Bulk Import FQDNs → {groupName}</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        {!result ? (
          <>
            {/* Tabs */}
            <div style={{ display: "flex", gap: 4, marginBottom: 14, borderBottom: "1px solid var(--border)", paddingBottom: 0 }}>
              {["paste", "file"].map(t => (
                <button key={t} onClick={() => setTab(t)}
                  style={{
                    background: "none", border: "none", cursor: "pointer",
                    padding: "8px 16px", fontSize: 13, fontWeight: 600,
                    color: tab === t ? "var(--primary)" : "var(--text-muted)",
                    borderBottom: tab === t ? "2px solid var(--primary)" : "2px solid transparent",
                    marginBottom: -1,
                  }}>
                  {t === "paste" ? "📋 Paste Text" : "📁 Upload CSV"}
                </button>
              ))}
            </div>

            {tab === "paste" ? (
              <>
                <p style={{ fontSize: 12, color: "var(--text-muted)", marginBottom: 8 }}>
                  One FQDN per line, or CSV: <code>fqdn, port, type(intranet/external), proxy(true/false)</code>
                </p>
                <textarea
                  style={{
                    width: "100%", height: 160, padding: 10,
                    border: "1px solid var(--border)", borderRadius: 6,
                    fontSize: 13, fontFamily: "monospace", resize: "vertical",
                    background: "var(--surface)", color: "var(--text)",
                  }}
                  placeholder={"example.com\ndev.azure.com,443,external,true\ninternal.example.com,443,intranet,false"}
                  value={text}
                  onChange={e => handleParse(e.target.value)}
                />
              </>
            ) : (
              <div style={{ textAlign: "center", padding: "28px 0" }}>
                <input type="file" ref={fileRef} accept=".csv,.txt" style={{ display: "none" }} onChange={handleFile} />
                <button className="btn btn-outline" onClick={() => fileRef.current.click()}>
                  📁 Choose CSV File
                </button>
                <p style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 8 }}>
                  Supports .csv and .txt files
                </p>
              </div>
            )}

            {/* Sample */}
            <details style={{ marginTop: 10 }}>
              <summary style={{ fontSize: 12, color: "var(--primary)", cursor: "pointer" }}>View sample CSV format</summary>
              <pre style={{ fontSize: 11, background: "#f8fafc", padding: 10, borderRadius: 6, marginTop: 6, overflow: "auto" }}>
                {SAMPLE_CSV}
              </pre>
            </details>

            {/* Preview */}
            {parsed.length > 0 && (
              <div style={{ marginTop: 14 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>
                  Preview — {parsed.length} FQDNs detected
                </div>
                <div style={{ maxHeight: 160, overflow: "auto", border: "1px solid var(--border)", borderRadius: 6 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                    <thead>
                      <tr style={{ background: "#f8fafc" }}>
                        <th style={{ padding: "7px 12px", textAlign: "left", color: "var(--text-muted)", fontWeight: 600 }}>FQDN</th>
                        <th style={{ padding: "7px 8px", textAlign: "center", color: "var(--text-muted)", fontWeight: 600 }}>Port</th>
                        <th style={{ padding: "7px 8px", textAlign: "center", color: "var(--text-muted)", fontWeight: 600 }}>Type</th>
                        <th style={{ padding: "7px 8px", textAlign: "center", color: "var(--text-muted)", fontWeight: 600 }}>Proxy</th>
                      </tr>
                    </thead>
                    <tbody>
                      {parsed.map((e, i) => (
                        <tr key={i} style={{ borderTop: "1px solid var(--border)" }}>
                          <td style={{ padding: "7px 12px", fontFamily: "monospace" }}>{e.fqdn}</td>
                          <td style={{ padding: "7px 8px", textAlign: "center" }}>{e.port}</td>
                          <td style={{ padding: "7px 8px", textAlign: "center" }}>
                            <span style={{ fontSize: 11, background: e.network_type === "intranet" ? "#eff6ff" : "#f0fdf4", color: e.network_type === "intranet" ? "#1d4ed8" : "#16a34a", padding: "2px 8px", borderRadius: 100 }}>
                              {e.network_type}
                            </span>
                          </td>
                          <td style={{ padding: "7px 8px", textAlign: "center" }}>
                            {e.use_proxy ? <span style={{ color: "#16a34a", fontSize: 12 }}>✓</span> : <span style={{ color: "var(--text-muted)", fontSize: 12 }}>—</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
              <button className="btn btn-primary" onClick={handleImport}
                disabled={!parsed.length || importing}>
                {importing ? "Importing..." : `Import ${parsed.length} FQDNs`}
              </button>
              <button className="btn btn-outline" onClick={onClose}>Cancel</button>
            </div>
          </>
        ) : result.error ? (
          <>
            <div className="alert alert-error">{result.error}</div>
            <button className="btn btn-outline" onClick={() => setResult(null)}>← Back</button>
          </>
        ) : (
          <>
            {/* Import Results */}
            <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
              <div style={{ background: "#dcfce7", color: "#16a34a", padding: "10px 16px", borderRadius: 8, flex: 1, textAlign: "center" }}>
                <div style={{ fontSize: 24, fontWeight: 700 }}>{result.imported.length}</div>
                <div style={{ fontSize: 12 }}>Imported</div>
              </div>
              <div style={{ background: "#fef3c7", color: "#d97706", padding: "10px 16px", borderRadius: 8, flex: 1, textAlign: "center" }}>
                <div style={{ fontSize: 24, fontWeight: 700 }}>{result.duplicates.length}</div>
                <div style={{ fontSize: 12 }}>Duplicates skipped</div>
              </div>
              <div style={{ background: "#fee2e2", color: "#dc2626", padding: "10px 16px", borderRadius: 8, flex: 1, textAlign: "center" }}>
                <div style={{ fontSize: 24, fontWeight: 700 }}>{result.errors.length}</div>
                <div style={{ fontSize: 12 }}>Errors</div>
              </div>
            </div>

            {result.duplicates.length > 0 && (
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#d97706", marginBottom: 6 }}>⚠ Duplicates skipped:</div>
                {result.duplicates.map((d, i) => (
                  <div key={i} style={{ fontSize: 12, fontFamily: "monospace", color: "var(--text-muted)", padding: "2px 0" }}>
                    {d.fqdn}:{d.port} — {d.reason}
                  </div>
                ))}
              </div>
            )}

            {result.errors.length > 0 && (
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#dc2626", marginBottom: 6 }}>✗ Errors:</div>
                {result.errors.map((e, i) => (
                  <div key={i} style={{ fontSize: 12, fontFamily: "monospace", color: "var(--text-muted)", padding: "2px 0" }}>
                    {e.fqdn} — {e.error}
                  </div>
                ))}
              </div>
            )}

            <button className="btn btn-primary" onClick={onClose}>Done</button>
          </>
        )}
      </div>
    </div>
  );
}
