import React, { useState } from "react";

const STATUS_MAP = {
  OK: { cls: "badge-ok", label: "OK" },
  Warning: { cls: "badge-warning", label: "Warning" },
  Critical: { cls: "badge-critical", label: "Critical" },
  Expired: { cls: "badge-error", label: "Expired" },
  Error: { cls: "badge-error", label: "Error" },
  "403 Proxy Blocked": { cls: "badge-proxy-blocked", label: "403 Proxy Blocked" },
  PENDING: { cls: "badge-pending", label: "Pending" },
};

export default function StatusBadge({ status, error }) {
  const { cls, label } = STATUS_MAP[status] || STATUS_MAP["PENDING"];
  const [expanded, setExpanded] = useState(false);
  const hasError = !!error && (status === "Error" || status === "Expired" || status === "403 Proxy Blocked");

  if (!hasError) {
    return <span className={`badge ${cls}`}>{label}</span>;
  }

  return (
    <span style={{ position: "relative", display: "inline-block" }}>
      <span
        className={`badge ${cls} badge-clickable`}
        title={error}
        onClick={() => setExpanded(!expanded)}
      >
        {label} <span className="badge-info-icon">ⓘ</span>
      </span>
      {expanded && (
        <div className="badge-error-popover" onClick={(e) => e.stopPropagation()}>
          <div className="badge-error-popover-header">
            <span>Error Details</span>
            <button className="badge-error-close" onClick={() => setExpanded(false)}>×</button>
          </div>
          <div className="badge-error-popover-body">{error}</div>
        </div>
      )}
    </span>
  );
}
