# SSL Monitor

A full-stack SSL certificate monitoring app — matching your existing dashboard layout.

## Features

- **Dashboard**: Live overview of all FQDNs across projects, split by Intranet/External
- **Projects**: Add/remove projects, groups (sub-categories), and FQDNs
- **Per-FQDN SSL Check**: Click 🔍 to check any individual domain on demand
- **Bulk Check**: "Check All Now" button triggers checks for every FQDN
- **Auto-polling**: SSL checks run automatically every 6 hours via cron
- **Status levels**: OK / Warning (≤30 days) / Critical (≤14 days) / Expired / Error
- **Auth**: JWT-based login with change-password support
- **Persistent DB**: SQLite — no external database needed

---

## Quick Start (Without Docker)

### 1. Backend

```bash
cd backend
npm install
node server.js
# Runs on http://0.0.0.0:8000
# Default login: admin / admin123
```

### 2. Frontend

```bash
cd frontend
npm install
npm start
# Runs on http://localhost:3000
# Proxies /api calls to localhost:8000
```

---

## Docker Deployment

Edit `docker-compose.yml` and replace `YOUR_SERVER_IP` with your actual server IP or domain.

```bash
# Build and start
docker-compose up -d --build

# View logs
docker-compose logs -f backend

# Stop
docker-compose down
```

Frontend: http://YOUR_SERVER:3000  
Backend API: http://YOUR_SERVER:8000

---

## Environment Variables

### Backend
| Variable | Default | Description |
|---|---|---|
| `PORT` | `8000` | Server port |
| `JWT_SECRET` | `ssl-monitor-secret-key-change-in-prod` | JWT signing key — **change in production** |

### Frontend (build-time)
| Variable | Default | Description |
|---|---|---|
| `REACT_APP_API_URL` | `` (empty = same host) | Backend URL (e.g. `http://10.144.166.59:8000`) |

---

## API Reference

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/login` | Login → JWT token |
| POST | `/api/auth/change-password` | Change password |
| GET | `/api/projects` | Get all projects + groups + FQDNs |
| POST | `/api/projects` | Create project |
| DELETE | `/api/projects/:id` | Delete project |
| POST | `/api/groups` | Create group |
| DELETE | `/api/groups/:id` | Delete group |
| POST | `/api/fqdns` | Add FQDN |
| DELETE | `/api/fqdns/:id` | Delete FQDN |
| POST | `/api/fqdns/:id/check` | Check one FQDN now |
| POST | `/api/fqdns/check-all` | Trigger check for all FQDNs |

---

## Production Notes

1. Change `JWT_SECRET` to a strong random value
2. Change the default `admin123` password after first login
3. The backend runs SSL checks from the server — ensure it can reach your intranet hosts
4. For HTTPS, place Nginx or a reverse proxy in front of both services
5. SQLite DB is stored at `backend/ssl_monitor.db` (or `/app/data/` in Docker)

---

## SSL Check Logic

The backend uses Node.js `tls.connect()` directly — no external tools required.

```
Status   | Condition
---------|----------
OK       | cert valid, > 30 days left
Warning  | cert valid, 15–30 days left
Critical | cert valid, ≤ 14 days left
Expired  | days_left <= 0
Error    | connection failed / no cert
```
